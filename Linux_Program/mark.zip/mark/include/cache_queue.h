/* no_lock cache queue implementation
* use atomic operation instead of mutex lock
* only apply to the communication between pthread and main process
* hxw 201807025
*/

#ifndef __CACHE_QUEUE_H__
#define __CACHE_QUEUE_H__


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "logger.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RESERVE_LEN_DEFAULT 65535

typedef struct cache_queue_s cache_queue_t;
struct cache_queue_s
{
    int read_index;
    int write_index;
    int reserve_len;  /* 预留长度，每次写入的数据长度必须小于预留长度 */
    int queue_len;    /* 队列总长度 */
};


int init_cache_queue(cache_queue_t *cache_queue, int reserve_len, int queue_len);
int en_cache_queue(cache_queue_t *cache_queue, char *buff, int buff_len);
int de_cache_queue(cache_queue_t *cache_queue, char *buff);
int is_cache_empty(cache_queue_t *cache_queue);
int get_cache_free_len(cache_queue_t *cache_queue);
int is_cache_writable(cache_queue_t *cache_queue);



#ifdef __cplusplus
}
#endif

#endif
