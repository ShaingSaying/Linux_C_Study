﻿#ifndef __CODE_CONVERT__
#define __CODE_CONVERT__

extern int code_convert(const char *from_charset, const char *to_charset, char *inbuf, size_t inlen, char *outbuf, size_t outlen);


#endif
