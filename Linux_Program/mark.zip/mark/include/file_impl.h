#ifndef __FILE_IMPL_H__
#define __FILE_IMPL_H__

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>



#ifdef __cplusplus
extern "C" {
#endif

#define MAX_FILE_LEN  256    /* 文件名最大长度 */

extern int make_multi_dir(const char *pdir);
extern int get_absolute_path(const char *pfilename, char *path,int max_len);
extern int get_absolute_file(const char *pfilename, char *filenname, int max_len);
extern int acquire_file_type(const char *pfilename);



#ifdef __cplusplus
}
#endif

#endif

