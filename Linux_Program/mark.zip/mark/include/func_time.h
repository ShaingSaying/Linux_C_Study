#ifndef __FUNC_TIME_H__
#define __FUNC_TIME_H__

#include <time.h>
#include <iostream>
#include "logger.h"
#include "utc_time.h"

#ifdef __cplusplus
extern "C" {
#endif

using namespace std;

class func_time
{
    public:
        func_time(long now, const char *func)
        {
            start = now;
            strncpy(name, func, 64);
            name[64] = '\0';
        }
        ~func_time()
        {
            long cost = get_utc_microseconds() - start;
            if(cost > 0)
            {
                LOG_FATAL("%s cost %ld", name, cost);
            }
        };
    private:
        long start;
        char name[64 + 1];
};

#ifdef __cplusplus
}
#endif

#endif
