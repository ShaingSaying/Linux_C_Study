/*
*  基于特定内存块实现的哈希结构，可以使用于一写一读的共享内存块，如果多写则需要加锁
*  hxw 20181207
*/

#ifndef __MEM_HASH_H__
#define __MEM_HASH_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#include "logger.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MIN_HASH_SIZE 10
#define MIN_LIST_SIZE 10
#define LIST_EMPTY 0

/* 所有index，除特定说明，均为相对与内存头地址的位移 */

/* 哈希节点 */
typedef struct hash_node_s hash_node_t;
struct hash_node_s
{
    //unsigned int hash_index;      /* 哈希节点index */
    unsigned int node_index;      /* 链表节点index */
};

/* 链表节点 */
/* 链表节点个数由内存大小和节点大小决定，最小个数为哈希节点个数 */
typedef struct list_node_s list_node_t;
struct list_node_s
{
    //unsigned int index;  /* 链表节点index */
    unsigned int next;   /* 下一个节点index */
    unsigned int key;    /* key的index */
    unsigned int val;    /* val的index */
};

/* 静态内存哈希表 */
/* 静态内存哈希表分为三个部分，结构信息 + 哈希节点 + 链表节点 */
typedef struct mem_hash_s mem_hash_t;
struct mem_hash_s
{
    unsigned int mem_size;    /* 内存总大小 */
    unsigned int hash_size;   /* 哈希节点个数 */
    unsigned int list_size;   /* 链表节点个数 */
    unsigned int key_size;    /* key大小 */
    unsigned int val_size;    /* val大小 */
    /* node_size = sizeof(list_node_t) + key_size + val_size */
    unsigned int node_size;   /* 链表节点大小 */

    unsigned int free_index;  /* 空闲的链表头节点index */

    unsigned int hash_head;   /* 哈希头节点index */
    unsigned int list_head;   /* 链表头节点index */

    pthread_mutexattr_t attr;
    pthread_mutex_t mutex;
};

/* 迭代器 */
typedef struct mem_hash_iterator_s mem_hash_iterator_t;
struct mem_hash_iterator_s
{
    unsigned int hash_num;   /* 当前哈希节点 */
    unsigned int node_next;  /* 下一个链表节点 */
};

int mem_hash_init(mem_hash_t *mem_hash, unsigned int mem_size, unsigned int hash_size, unsigned int key_size, unsigned int val_size);
int mem_hash_add(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size);
int mem_hash_add_ifnotexist(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size);
int mem_hash_delete(mem_hash_t *mem_hash, char *key, unsigned int key_size);
int mem_hash_delete_return(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size);
int mem_hash_find(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size);
int mem_hash_find_val_index(mem_hash_t *mem_hash, char *key, unsigned int key_size, unsigned int *val_index);
int mem_hash_dump(mem_hash_t *mem_hash);
mem_hash_iterator_t* mem_hash_get_iterator(mem_hash_t *mem_hash);
void mem_hash_release_iterator(mem_hash_iterator_t *itr);
int mem_hash_next(mem_hash_t *mem_hash, mem_hash_iterator_t *itr, unsigned int *node_index);

#ifdef __cplusplus
}
#endif

#endif
