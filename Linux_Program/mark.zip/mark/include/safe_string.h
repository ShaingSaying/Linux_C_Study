#ifndef __SAFE_STRING_H__
#define __SAFE_STRING_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 


#ifdef __cplusplus
extern "C" {
#endif

#define char_tolower(c)      (u_char) ((c >= 'A' && c <= 'Z') ? (c | 0x20) : c)
#define char_toupper(c)      (u_char) ((c >= 'a' && c <= 'z') ? (c & ~0x20) : c)

void strupr(u_char *dst, u_char *src, size_t n);
void strlow(u_char *dst, u_char *src, size_t n);
char *safe_strncpy(char *dst, const char *src, size_t n);
char *safe_strcat(char *dst, const char *src, size_t n);

int replace_char(char *c_srcstr, int isrcstrLen, char* c_judgestr, int ijudgestrLen, char c_dst);
int remove_char(char * ch, char c);
unsigned int str2uint(char* pstr, unsigned int length);

void trim_space(char* p, int length);

unsigned int chars2uint(char* source, unsigned int length);

int replace_char_ex(char *c_srcstr, int isrcstrLen, char* c_judgestr, int ijudgestrLen, char* c_dst);



#ifdef __cplusplus
}
#endif

#endif

