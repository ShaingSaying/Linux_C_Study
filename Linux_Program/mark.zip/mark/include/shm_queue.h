/* no_lock shm queue implementation
* use atomic operation instead of mutex lock
* hxw 20180709
*/

#ifndef __SHM_QUEUE_H__
#define __SHM_QUEUE_H__


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/shm.h>

#include "logger.h"
#include "shm_base.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LEN_LEN 6
#define LEN_FORMAT "%06d"

typedef struct shm_queue_s shm_queue_t;
struct shm_queue_s
{
    int shm_id;
    int last_read_index;
    int read_index;
    int write_index;
    int queue_len;

    pthread_mutexattr_t attr;
    pthread_mutex_t mutex;
};


int init_shm_queue(shm_queue_t *shm_queue, int shm_id, int queue_len);
int is_shm_queue_empty(shm_queue_t *shm_queue);
int get_shm_queue_free_len(shm_queue_t *shm_queue);
int en_shm_queue(shm_queue_t *shm_queue, char *buff, int buff_len);
int de_shm_queue(shm_queue_t *shm_queue, char *buff, int *buff_len);



#ifdef __cplusplus
}
#endif

#endif
