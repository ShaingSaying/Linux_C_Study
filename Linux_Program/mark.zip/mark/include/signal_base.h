/* signal base function
* hxw 20180918
*/

#ifndef __SIGNAL_BASE_H__
#define __SIGNAL_BASE_H__


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void sigfunc(int32_t);
sigfunc *register_signal(int32_t signo, sigfunc *func);


#ifdef __cplusplus
}
#endif

#endif
