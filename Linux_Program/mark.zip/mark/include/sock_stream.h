#ifndef __SOCK_STREAM_H__
#define __SOCK_STREAM_H__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <linux/netlink.h>
#include <arpa/inet.h>

#include "logger.h"
#include "compiler.h"


#ifdef __cplusplus
extern "C" {
#endif

enum
{
    SOCK_ERR_NONE   = 0,
    SOCK_ERR_BROKEN = 1,
    SOCK_ERR_BLOCK  = 2,
    SOCK_ERR_PIPE   = 3,
    SOCK_ERR_OTHER  = 4,
};

typedef struct data_to_kernel_s data_to_kernel_t;
struct data_to_kernel_s
{
	struct nlmsghdr hdr;
	char data[0];
};

int netlink_socket(int netlink_protocol);
int netlink_bind(int fd);
int netlink_recv(int fd, char *buff, int len);
int32_t netlink_recv_timeout(int fd, char *buff, int len, int sec);
int netlink_send(int fd, data_to_kernel_t *data, int len);

int create_ipv4_socket();
int create_un_socket();
int tcp_server_socket(int port, int *sock);
int tcp_client_socket(char *ip, int port, int *sock);
int tcp_accept(int fd);

int tcp_send(int fd, char *buf, int len);
int tcp_recv(int fd, char *buf, int len);

int set_nonblock(int fd);

#ifdef __cplusplus
}
#endif

#endif

