#ifndef __THREAD_IMPL_H__
#define __THREAD_IMPL_H__


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#ifdef __cplusplus
extern "C" {
#endif

int pthread_create_detached(pthread_t* handle, void *(*func)(void*), void *param);


#ifdef __cplusplus
}
#endif

#endif
