#ifndef __UTC_TIME_H__
#define __UTC_TIME_H__

#include <stdint.h>
#include <time.h>
#include <sys/time.h>

#ifdef __cplusplus
extern "C" {
#endif

time_t get_utc_seconds();
time_t get_1970_seconds();

long get_utc_microseconds();
long get_utc_miliseconds();
long timestap_to_utc_microseconds(struct timeval *tv);
int microseconds_to_str(long microsec, char* dest, int dest_len);
double get_time_interval_sec(struct timeval *start);

#ifdef __cplusplus
}
#endif

#endif

