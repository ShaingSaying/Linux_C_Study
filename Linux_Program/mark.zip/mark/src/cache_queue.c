#include "cache_queue.h"

/**********************************************************************
* 函 数 名 : init_cache_queue
* 功能描述 : 初始化缓存循环队列
* 输入参数 : cache_queue_t *cache_queue 缓存循环队列
*            int reserve_len 预留长度
*            int queue_len 队列长度
*
* 输出参数 : 无
*
* 返 回 值 : 0 成功 
*            -1 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
int init_cache_queue(cache_queue_t *cache_queue, int reserve_len, int queue_len)
{
    if(NULL == cache_queue || 0 > reserve_len || 0 >= queue_len)
    {
        LOG_ERROR("param error");
        return -1;
    }

    cache_queue->read_index = 0;
    cache_queue->write_index = 0;
    cache_queue->reserve_len = reserve_len;
    cache_queue->queue_len = queue_len;
    
    return 0;
}

int is_cache_empty(cache_queue_t *cache_queue)
{
    return cache_queue->write_index == cache_queue->read_index ? 0 : -1;
}

int get_cache_free_len(cache_queue_t *cache_queue)
{
    int free_len = 0;
    int write_index = cache_queue->write_index;
    int read_index = cache_queue->read_index;
    int reserve_len = cache_queue->reserve_len;
    int queue_len = cache_queue->queue_len;

    if(write_index < queue_len - reserve_len)
    {
        free_len = write_index >= read_index ? (queue_len - write_index + read_index) : read_index - write_index;
    }
    else
    {
        /* 写位移达到预留空间，置0 */
        __sync_lock_test_and_set(&(cache_queue->write_index), 0);
        free_len = read_index;
    }

    return free_len;
}

int is_cache_writable(cache_queue_t *cache_queue)
{
    if(cache_queue->reserve_len < get_cache_free_len(cache_queue))
    {
        return 0;
    }
    else
    {
        return -1;
    }
}

int en_cache_queue(cache_queue_t *cache_queue, char *buff, int buff_len)
{

    return 0;
}

int de_cache_queue(cache_queue_t *cache_queue, char **buff)
{
    
    if(0 == is_cache_empty(cache_queue))
    {
        LOG_ERROR("cache queue is empty");
        return -1;
    }

    
    return 0;
}
