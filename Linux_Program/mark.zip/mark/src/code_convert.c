﻿#include <stdio.h>
#include <stdlib.h>
#include <iconv.h>
#include <string.h>
#include <inttypes.h>
#include "../include/code_convert.h"


//代码转换:从一种编码转为另一种编码
int code_convert(const char *from_charset, const char *to_charset, char *inbuf, size_t inlen, char *outbuf, size_t outlen)
{
    iconv_t cd;
    int rc;
    char **pin = &inbuf;
    char **pout = &outbuf;

    cd = iconv_open(to_charset,from_charset);
	if(cd == (iconv_t)-1)
	{
	    return -1;
	}
   
    memset(outbuf,0,outlen);
    if (iconv(cd,pin,&inlen,pout,&outlen) == -1)
    {
        iconv_close(cd);
		return -1;
    }
	iconv_close(cd);
    return 0;
}





