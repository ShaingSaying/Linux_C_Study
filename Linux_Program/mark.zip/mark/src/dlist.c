#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "compiler.h"
#include "dlist.h"
//#include "logger.h"


dlist_t *dlist_create()
{
    dlist_t *list = (dlist_t*)malloc(sizeof(dlist_t));
    if(unlikely(NULL == list))
        goto MALLOC_FAILED;

    list->head = (dlist_entry_t*)malloc(sizeof(dlist_entry_t));
    if(unlikely(NULL == list->head))
        goto MALLOC_FAILED;
    list->head->prev = list->head->next = NULL;
    list->head->data = NULL;

    list->tail = (dlist_entry_t*)malloc(sizeof(dlist_entry_t));
    if(unlikely(NULL == list->tail))
        goto MALLOC_FAILED;
    list->tail->prev = list->tail->next = NULL;
    list->tail->data = NULL;

    list->head->next = list->tail;
    list->tail->prev = list->head;

    list->len = 0;

    return list;

MALLOC_FAILED:

    LOG_ERROR("dlist_create malloc failed");

    if(list)
    {
        if(list->head)
        {
            CHECK_FREE(list->head);
        }
        CHECK_FREE(list);
    }

    return NULL;
}

int dlist_insert(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        LOG_ERROR("dlist_insert param error");
        return -1;
    }

    dlist_entry_t *item = (dlist_entry_t*)malloc(sizeof(dlist_entry_t)); 
    if (unlikely(NULL == item))
    {
        LOG_ERROR("dlist_insert malloc failed");
        return -1;
    }

    item->next = NULL;
    item->prev = NULL;
    item->data = data;

    list->head->next->prev = item;
    item->prev = list->head;
    item->next = list->head->next;
    list->head->next = item;

    list->len++;

    return 0;
}

int dlist_insert_and_fetch(dlist_t *list, void *data, dlist_entry_t **item)
{
    if (unlikely(NULL == list || NULL == data))
    {
        LOG_ERROR("param error");
        return -1;
    }

    dlist_entry_t *tmp = (dlist_entry_t *)malloc(sizeof(dlist_entry_t)); 
    if (unlikely(NULL == tmp))
    {
        LOG_ERROR("dlist_entry_t malloc failed");
        return -1;
    }

    tmp->next = NULL;
    tmp->prev = NULL;
    tmp->data = data;

    list->head->next->prev = tmp;
    tmp->prev = list->head;
    tmp->next = list->head->next;
    list->head->next = tmp;

    list->len++;

    *item = tmp;
    return 0;
}

/* data必须是字符串 */
int dlist_insert_in_order(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("point is NULL.\n");
        return -1;
    }

    dlist_entry_t *item = (dlist_entry_t*)malloc(sizeof(dlist_entry_t)); 
    if (unlikely(NULL == item))
    {
        //LOG_ERROR("malloc failed.\n");
        return -1;
    }

    /*memset(item, 0, sizeof(struct dlist));*/
    item->next = NULL;
    item->prev = NULL;
    item->data = data;

	dlist_entry_t *tmp = NULL;
	list_for_each(tmp, list->head, list->tail)    
	{
		/* esc, data必须是字符串 */
		if(0 < strcmp((char *)tmp->data, (char*)data))
		{
			break;
		}
	}

	item->prev = tmp->prev;
	tmp->prev->next = item;
	item->next = tmp;
	tmp->prev = item;

    list->len++;

    return 0;
}

int dlist_insert_prev_by_node(dlist_t *list, dlist_entry_t *node, void *data)
{
    if (unlikely(NULL == node || NULL == data))
    {
        LOG_ERROR("dlist_insert_prev_by_node param error");
        return -1;
    }
    
    dlist_entry_t *item = (dlist_entry_t *)malloc(sizeof(dlist_entry_t)); 
    if(unlikely(NULL == item))
    {
        LOG_ERROR("dlist_insert_prev_by_node, malloc item failed");
        return -1;
    }

    item->next = NULL;
    item->prev = NULL;
    item->data = data;

    node->prev->next = item;
    item->next = node;
    item->prev = node->prev;
    node->prev = item;
    
    list->len++;

    return 0;
}

int dlist_insert_tail(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("point is NULL.\n");
        return -1;
    }

    dlist_entry_t *item = (dlist_entry_t*)malloc(sizeof(dlist_entry_t)); 
    if (unlikely(NULL == item))
    {
        //LOG_ERROR("dlist_insert_tail:malloc item failed\n");
        return -1;
    }

    item->next = NULL;
    item->prev = NULL;
    item->data = data;

    list->tail->prev->next = item;
    item->next = list->tail;
    item->prev = list->tail->prev;
    list->tail->prev = item;

    list->len++;

    return 0;
}

int dlist_find_insert_from_tail(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("point is NULL.\n");
        return -1;
    }

    if (dlist_find_from_tail(list, data) == 0)
    {
        //LOG_DEBUG("dlist_find_from_tail same\n");
        return 0;
    }

    return dlist_insert_tail(list, data);
}

/*
//data should be string
int dlist_compare_order_list(dlist_t *list1, dlist_t *list2)
{
	if (unlikely(NULL == list1 || NULL == list2))
    {
        //LOG_ERROR("point is NULL.\n");
        return -1;
    }

	if(list1->len != list2->len);
	{
		return -1;
	}

	dlist_entry_t *item1 = NULL;
	dlist_entry_t *item2 = NULL;

	for(item1 = list1->head->next, item2 = list2->head->next; item1 != list1->tail && item2 != list2->tail; item1 = item1->next, item2 = item2->next)
	{
		if(0 != strcmp(item1->data, item2->data))
		{
			return -1;
		}
	}

	return 0;
}
*/
/*
//data should be string
int dlist_combine_order_list(dlist_t *list1, dlist_t *list2)
{
	if (unlikely(NULL == list1 || NULL == list2))
    {
        //LOG_ERROR("point is NULL.\n");
        return -1;
    }

	dlist_entry_t *item1 = list1->head->next;
	dlist_entry_t *item2 = list2->head->next;
	dlist_entry_t *tmp_prev = NULL;
	dlist_entry_t *tmp_next = NULL;

	while(item1 != list1->tail && item2 != list2->tail)
	{
		tmp_prev = item2->prev;
		tmp_next = item2->next;
		if(0 < strcmp(item1->data, item2->data))
		{
			item2->prev = item1->prev;
			item1->prev->next = item2;
			item2->next = item1;
			item1->prev = item2;
	
			tmp_prev->next = tmp_next;
			tmp_next->prev = tmp_prev;

            item1 = item1->next;
            item2 = tmp_next;
		}
		else if(0 > strcmp(item1->data, item2->data))
		{
		    item2->prev = item1;
			item2->next = item1->next;
			item1->next->prev = item2;
			item1->next = item2;
			
			tmp_prev->next = tmp_next;
			tmp_next->prev = tmp_prev;

			item1 = item1->next->next;
            item2 = tmp_next;
		}
		else
		{
			//equal
            item1 = item1->next;
            item2 = item2->next;
		}
	}

    tmp_prev = item2->prev;
    while(item2 != list2->tail)
    {
        tmp_next = item2->next;

		list1->tail->prev->next = item2;
	    item2->next = list1->tail;
	    item2->prev = list1->tail->prev;
	    list1->tail->prev = item2;
		
        item2 = tmp_next;
    }

    tmp_prev->next = list2->tail;
    list2->tail->prev = tmp_prev;
	//dlist_destroy(list2); //not destroy at here
	return 0;
}
*/

int dlist_delete(dlist_t *list, void *data, int is_free_data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("point is NULL.\n");
        return -1;
    }

    dlist_entry_t *item = NULL;
    list_for_each(item, list->head, list->tail)
    {
        if (data == item->data)
        {
            item->prev->next = item->next;
            item->next->prev = item->prev;
            list->len--;

            if(is_free_data == DLIST_FREE_DATA && item->data)
            {
                CHECK_FREE(item->data);
                item->data = NULL;
            }

            CHECK_FREE(item);
            item = NULL;
            
            return 0;
        }
    }

    //LOG_WARN("data not found.\n");
    return -1;
}


/* 节点必须存在 */
int dlist_delete_by_node(dlist_t *list, dlist_entry_t *node, int is_free_data)
{
    if(unlikely(NULL == list || NULL == node))
    {
        LOG_ERROR("dlist_delete_by_node: param error");
        return -1;
    }

    node->prev->next = node->next;
    node->next->prev = node->prev;
    list->len--;

    if(DLIST_FREE_DATA == is_free_data && node->data)
    {
        CHECK_FREE(node->data);
    }
    CHECK_FREE(node);

    return 0;
}

//find and delete
int dlist_find_and_delete_by_node(dlist_t *list, dlist_entry_t *node, int is_free_data)
{
    if(unlikely(NULL == list || NULL == node))
    {
        LOG_ERROR("param is NULL");
        return -1;
    }

    if(node == list->head || node == list->tail)
    {
        LOG_ERROR("can't delete head and tail");
        return -1;
    }
    
    dlist_entry_t *item = NULL;
    list_for_each(item, list->head, list->tail)
    {
        if(node == item)
        {
            node->prev->next = node->next;
            node->next->prev = node->prev;
            list->len--;

            if(DLIST_FREE_DATA == is_free_data && node->data)
            {
                CHECK_FREE(node->data);
            }
            
            CHECK_FREE(node);
            break;
        }
    }
    return 0;
}

int dlist_delete_all(dlist_t *list, int is_free_data)
{
    if (unlikely(NULL == list))
    {
        LOG_ERROR("dlist_delete_all: list is NULL");
        return -1;
    }

    dlist_entry_t *item = NULL;
    for(item = list->head->next; item != list->tail; )
    {
        item->prev->next = item->next;
        item->next->prev = item->prev;
        list->len--;

        dlist_entry_t *tmp = item->next;

        if(is_free_data == DLIST_FREE_DATA && item->data)
        {
            CHECK_FREE(item->data);
        }

        CHECK_FREE(item); 

        item = tmp;
    }

    return 0;
}

int dlist_delete_from_tail(dlist_t *list, void *data, int is_free_data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("point is NULL.\n");
        return -1;
    }

    dlist_entry_t *item = NULL;

    for(item = list->tail->prev; item != list->head; item = item->prev)    
    {
        if (data == item->data)
        {
            item->prev->next = item->next;
            item->next->prev = item->prev;
            list->len--;
            
            if(is_free_data == DLIST_FREE_DATA && item->data)  
            {
                CHECK_FREE(item->data);
                item->data = NULL;
            }

            CHECK_FREE(item);
            item = NULL;

            return 0;
        }
    }

    //LOG_WARN("data not found.\n");
    return -1;
}

int dlist_find(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("dlist_find:pointer is NULL\n");
        return -1;
    }

    dlist_entry_t *item = NULL;
    list_for_each(item, list->head, list->tail)    
    {
        if (data == item->data)
            return 0;
    }

    return -1;
}

/*
int dlist_find_str(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("dlist_find:pointer is NULL\n");
        return -1;
    }

    dlist_entry_t *item = NULL;
    list_for_each(item, list->head, list->tail)    
    {
        if (0 == memcmp(data, item->data, strlen(data)))
            return 0;
    }

    return -1;
}
*/

/* data必须是字符串 */
int dlist_find_str_uncase(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("dlist_find:pointer is NULL\n");
        return -1;
    }

    dlist_entry_t *item = NULL;
    list_for_each(item, list->head, list->tail)    
    {
        if (0 == strcasecmp((const char*)data, (const char*)(item->data)))
            return 0;
    }

    return -1;
}


int dlist_find_from_tail(dlist_t *list, void *data)
{
    if (unlikely(NULL == list || NULL == data))
    {
        //LOG_ERROR("dlist_find:pointer is NULL\n");
        return -1;
    }

    dlist_entry_t *item = NULL;
    for (item = list->tail->prev; item != list->head; item = item->prev)
    {
        if (data == item->data)
            return 0;
    }

    return -1;
}

/* 节点移动到表头 */
int dlist_entry_to_head(dlist_t *list, dlist_entry_t *item)
{
    if (unlikely(NULL == list || NULL == item))
    {
        LOG_ERROR("param is NULL");
        return -1;
    }

    if(item == list->head || item == list->tail)
    {
        LOG_ERROR("list is empty");
        return 0;
    }

    if(1 == list->len)
    {
        return 0;
    }

    /* 从原位置剔除 */
    item->prev->next = item->next;
    item->next->prev = item->prev;
    /* 插入链表头 */
    list->head->next->prev = item;
    item->prev = list->head;
    item->next = list->head->next;
    list->head->next = item;

    return 0;
}

int dlist_get_length(dlist_t *list)
{
    if(unlikely(NULL == list))
    {
        //LOG_ERROR("dlist_get_length:pointer is NULL\n");
        return -1;
    }

    return list->len;
}

int dlist_destroy(dlist_t *list)
{
    if(unlikely(NULL == list))
    {
        LOG_ERROR("dlist_destroy: pointer is NULL");
        return -1;
    }
    
    dlist_delete_all(list, DLIST_FREE_DATA);

    free(list->head);
    free(list->tail);
    free(list);

    return 0;
}

