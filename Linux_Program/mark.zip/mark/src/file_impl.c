#include "file_impl.h"

/* 创建多级目录 */
int make_multi_dir(const char *pdir)
{
	char dir_temp[MAX_FILE_LEN];
	int len,i;

	if(pdir == NULL)
	{
		return -1;
	}

	if(access(pdir, F_OK) == 0)
	{
		return 0;
	}
	
	snprintf(dir_temp, MAX_FILE_LEN, "%s",pdir);
	len = strlen(dir_temp);

	for(i = 0; i < len; i++)
	{
		if(dir_temp[i] == '/')
		{
			dir_temp[i] = '\0';
			if(access(dir_temp, F_OK)!=0)
			{
				mkdir(dir_temp,0644);
			}
			dir_temp[i] = '/';
		}
	}

	if(len > 0 && access(dir_temp,F_OK)!=0)
	{
		mkdir(dir_temp, 0644);
	}

	return 1;
}

/* 根据绝对路径的文件名获取绝对路径 */
int get_absolute_path(const char *pfilename, char *path,int max_len)
{
	char *ptemp = NULL; 
	int n = 0;		/* 文件长度 */
	int m = 0;		/* 路径长度 */
	int len;

	if(pfilename == NULL || path == NULL || max_len <= 0)
	{
		return -1;
	}

	len = strlen(pfilename);
	if(strlen(pfilename) <= 0)
	{
		return -1;
	}
		
	ptemp = (char *)(pfilename+(len-1));	/* 指到指针尾部 */	
	
	while(*ptemp && *ptemp!='/')	/* 反向遍历，找到 ‘/’ */
	{
		ptemp--;
		n++;
	}
	n++;						/* 取得路径之后文件的长度 */
	m = strlen(pfilename)-n;	/* 路径的长度 */
	
	m = (m > max_len-1)?max_len-1:m;
	
	if(*ptemp=='/' && m > 0)
	{
		memcpy(path, pfilename, m); /* 拷贝路径 */
		path[m] = '\0';
	}
	
	return 1; 
}

/* 根据绝对路径的文件名获取文件名 */
int get_absolute_file(const char *pfilename, char *filenname, int max_len)
{
	char *ptemp = NULL; 

	if(pfilename == NULL || filenname == NULL || max_len <= 0)
	{
		return -1;
	}

	ptemp = (char *)(pfilename+(strlen(pfilename)-1));	/* 指到指针尾部 */	
	
	while(*ptemp && *ptemp!='/')	/* 反向遍历，找到 ‘/’ */
	{
		ptemp--;
	}
	ptemp++;

	/* 拷贝文件名 */
	snprintf(filenname, max_len, "%s", ptemp);
	
	return 1; 
}

/* 获取文件类型 */
int acquire_file_type(const char *pfilename)
{
	struct stat stat_info;	

	if(pfilename == NULL)
	{
		return -1;
	}

	if(stat(pfilename,&stat_info) == -1) /* 获取文件信息 */
	{
		return -1;
	}
	else
	{
		if(S_ISDIR(stat_info.st_mode))	/* 判断是否为目录 */
		{
			return 0;
		}
		else if(S_ISREG(stat_info.st_mode)) /* 判断是否为常规文件 */
		{
			return 1;
		}
		else 						/* 其它文件 */
		{
			return 2;
		}
	}
}

