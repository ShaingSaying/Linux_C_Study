#include "mem_hash.h"

/* redis 字典结构的哈希值算法 */
unsigned int gen_hash(const unsigned char *buf, unsigned int len)
{
    unsigned int hash = 5381;

    while(len--) hash = ((hash << 5) + hash) + (*buf++); /* hash * 33 + c */  
    return hash;
}

unsigned int node_init(mem_hash_t *mem_hash, char *key, char *val)
{
    list_node_t *node_tmp = NULL;
    unsigned int index_tmp = mem_hash->free_index;
    if(LIST_EMPTY == index_tmp)
    {
       // LOG_ERROR("no free node");
        return LIST_EMPTY;
    }

    node_tmp = (list_node_t *)((char *)mem_hash + index_tmp);
    mem_hash->free_index = node_tmp->next;

    node_tmp->next = LIST_EMPTY;
    //printf("")
    memcpy((char *)mem_hash + node_tmp->key, key, mem_hash->key_size);
    memcpy((char *)mem_hash + node_tmp->val, val, mem_hash->val_size);

    return index_tmp;
}

void node_release(mem_hash_t *mem_hash, unsigned int node_index)
{
    ((list_node_t *)((char *)mem_hash + node_index))->next = mem_hash->free_index;      /* ??? */
    mem_hash->free_index = node_index;
}

int hash_add(mem_hash_t *mem_hash, char *key, unsigned int new_index)
{
    int hash_num = 0;
    unsigned int current_index = 0;
    unsigned int next_index = 0;
    hash_node_t *hash_node_tmp = NULL;
    list_node_t *list_node_tmp = NULL;

    /* 计算哈希值 */
    hash_num = (gen_hash((const unsigned char*)key, mem_hash->key_size)) % mem_hash->hash_size;

    hash_node_tmp = (hash_node_t *)((char *)mem_hash + mem_hash->hash_head + sizeof(hash_node_t) * hash_num);
    current_index = hash_node_tmp->node_index; //存储节点的相对偏移位置
    if(LIST_EMPTY == current_index)
    {
        hash_node_tmp->node_index = new_index;
    }
    else
    {
        /* 把新节点接到链表尾 */
        /* current_index是相对mem_hash头部的偏移位置 */
        next_index = ((list_node_t *)((char *)mem_hash + current_index))->next;
        while(LIST_EMPTY != next_index)
        {
            current_index = next_index;
            next_index = ((list_node_t *)((char *)mem_hash + current_index))->next;
        }
        ((list_node_t *)((char *)mem_hash + current_index))->next = new_index;
    }

    return 0;
}

int hash_delete(mem_hash_t *mem_hash, char *key, unsigned int *node_index)
{
    int hash_num = 0;
    unsigned int current_index = 0;
    unsigned int next_index = 0;
    hash_node_t *hash_node_tmp = NULL;
    list_node_t *list_node_prev = NULL;
    list_node_t *list_node_current = NULL;

    /* 计算哈希值 */
    hash_num = (gen_hash((const unsigned char*)key, mem_hash->key_size)) % mem_hash->hash_size;
    hash_node_tmp = (hash_node_t *)((char *)mem_hash + mem_hash->hash_head + sizeof(hash_node_t) * hash_num);
    current_index = hash_node_tmp->node_index;

    do
    {
        if(LIST_EMPTY == current_index)
        {
            break;
        }
        else
        {
            /* 单独判断第一个链表节点，因为每个哈希链表首节点是哈希节点，后面的是链表节点 */
            list_node_current = (list_node_t *)((char *)mem_hash + current_index);
            if(0 == memcmp((char *)mem_hash + list_node_current->key, key, mem_hash->key_size))
            {
                hash_node_tmp->node_index = list_node_current->next;
                break;
            }
            else
            {
                /* 循环判断链表节点key */
                list_node_prev = list_node_current;
                current_index = list_node_current->next;
                while(LIST_EMPTY != current_index)
                {
                    list_node_current = (list_node_t *)((char *)mem_hash + current_index);
                    if(0 == memcmp((char *)mem_hash + list_node_current->key, key, mem_hash->key_size))
                    {
                        list_node_prev->next = list_node_current->next;
                        break;
                    }
                    else
                    {
                        list_node_prev = list_node_current;
                        current_index = list_node_current->next;
                    }
                }
            }
        }
    }while(0);

    if(LIST_EMPTY == current_index)
    {
        return -1;
    }
    else
    {
        *node_index = current_index;
        return 0;
    }
}


int hash_find(mem_hash_t *mem_hash, char *key, unsigned int *node_index)
{
    int hash_num = 0;
    unsigned int current_index = 0;
    unsigned int next_index = 0;
    hash_node_t *hash_node_tmp = NULL;
    list_node_t *list_node_current = NULL;

    /* 计算哈希值 */
    hash_num = (gen_hash((const unsigned char*)key, mem_hash->key_size)) % mem_hash->hash_size;
    hash_node_tmp = (hash_node_t *)((char *)mem_hash + mem_hash->hash_head + sizeof(hash_node_t) * hash_num);
    current_index = hash_node_tmp->node_index;

    do
    {
        if(LIST_EMPTY == current_index)
        {
            break;
        }
        else
        {
            /* 单独判断第一个链表节点，因为每个哈希链表首节点是哈希节点，后面的是链表节点 */
            list_node_current = (list_node_t *)((char *)mem_hash + current_index);
            if(0 == memcmp((char *)mem_hash + list_node_current->key, key, mem_hash->key_size))
            {
                //printf("current_index:%u\n", current_index);
                break;
            }
            else
            {
                /* 循环判断链表节点key */
                current_index = list_node_current->next;
                while(LIST_EMPTY != current_index)
                {
                    list_node_current = (list_node_t *)((char *)mem_hash + current_index);
                    if(0 == memcmp((char *)mem_hash + list_node_current->key, key, mem_hash->key_size))
                    {
                        //printf("current_index:%u\n", current_index);
                        break;
                    }
                    else
                    {
                        current_index = list_node_current->next;
                    }
                }
            }
        }
    }while(0);

    if(LIST_EMPTY == current_index)
    {
        return -1;
    }
    else
    {
        *node_index = current_index;
        return 0;
    }
}

/* 初始化 */
int mem_hash_init(mem_hash_t *mem_hash, unsigned int mem_size, unsigned int hash_size, unsigned int key_size, unsigned int val_size)
{
    int num = 0;
    int node_num = 0;
    unsigned int min_mem_size = 0;
    unsigned int list_node_size = 0;
    unsigned int list_head_tmp = 0;
    hash_node_t *hash_node_tmp = NULL;
    list_node_t *list_node_tmp = NULL;

    /* 入参检查 */
    if(NULL == mem_hash)
    {
        //LOG_ERROR("mem_hash is NULL");
        return -1;
    }
    if(MIN_HASH_SIZE > hash_size)
    {
       // LOG_ERROR("hash_size must bigger then %d", MIN_HASH_SIZE);
        return -1;
    }
    if(0 >= key_size || 0 >= val_size)
    {
       // LOG_ERROR("key_size or val_size error");
        return -1;
    }


    list_node_size = sizeof(list_node_t) + key_size + val_size;
    min_mem_size = sizeof(mem_hash_t) + sizeof(hash_node_t) * hash_size +  list_node_size * hash_size;
    if(min_mem_size > mem_size)
    {
       // LOG_ERROR("mem_size must bigger then %d", min_mem_size);
        return -1;
    }

    mem_hash->mem_size = mem_size;
    mem_hash->hash_size = hash_size;
    mem_hash->key_size = key_size;
    mem_hash->val_size = val_size;
    mem_hash->node_size = list_node_size;

    mem_hash->free_index = sizeof(mem_hash_t) + sizeof(hash_node_t) * hash_size;

    mem_hash->hash_head = sizeof(mem_hash_t);
    mem_hash->list_head = sizeof(mem_hash_t) + sizeof(hash_node_t) * hash_size;

    /* 初始化哈希节点 */
    /* 将哈希节点赋值为空 */
    for(num = 0; num < hash_size; num++)
    {
        hash_node_tmp = (hash_node_t *)((char *)mem_hash + mem_hash->hash_head + sizeof(hash_node_t) * num);
        hash_node_tmp->node_index = LIST_EMPTY;
    }

    /* 初始化链表节点 */
    node_num = 0;
    list_head_tmp = mem_hash->list_head;
    while(1)
    {
        node_num++;
        list_node_tmp = (list_node_t *)((char *)mem_hash + list_head_tmp);
        list_node_tmp->next = list_head_tmp + mem_hash->node_size;
        list_node_tmp->key = list_head_tmp + sizeof(list_node_t);
        list_node_tmp->val = list_node_tmp->key + mem_hash->key_size;
        /* 循环初始化链表结构 */
        if((list_head_tmp + mem_hash->node_size) < mem_hash->mem_size)
        {
            list_head_tmp += mem_hash->node_size;
        }
        else
        {
            break;
        }
    }
    /* 最后一个节点 */
    list_node_tmp->next = LIST_EMPTY;
    /* 初始化最后的结构就是获取链表个数 */
    mem_hash->list_size = node_num;

    return 0;
}


int mem_hash_add(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size)
{
    int ret = -1;
    unsigned int node_index = 0;
    /* 入参检测 */
    if(NULL == mem_hash || NULL == key || NULL == val)
    {
       // LOG_ERROR("param is NULL");
        return -1;
    }
    /* 入参检测key和val的大小一定要与结构体设计的大小一样 */
    if(key_size != mem_hash->key_size || val_size != mem_hash->val_size)
    {
       // LOG_ERROR("size error, key_size:%u, val_size:%u", key_size, val_size);
        return -1;
    }

    /* 获取一个链表节点 */
    /* 将key和val存入list_node中,返回的是位置相对头的偏移位置 */
    node_index = node_init(mem_hash, key, val);
    if(LIST_EMPTY == node_index)
    {
       // LOG_ERROR("node_init error");
        return -1;
    }

    /* 插入哈希表 */
    /* 将存入key和val的节点相对于头部的偏移位置赋予哈希表的节点位置 */
    ret = hash_add(mem_hash, key, node_index);
    if(0 != ret)        /* 当前只有返回值0 */
    {
        /* 异常则回收链表节点 */
        node_release(mem_hash, node_index);
    }

    return 0;
}


int mem_hash_add_ifnotexist(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size)
{
    int ret = -1;
    unsigned int node_index = 0;

    if(NULL == mem_hash || NULL == key || NULL == val)
    {
       // LOG_ERROR("param is NULL");
        return -1;
    }
    if(key_size != mem_hash->key_size || val_size != mem_hash->val_size)
    {
       // LOG_ERROR("size error, key_size:%u, val_size:%u", key_size, val_size);
        return -1;
    }

    /* 从哈希表查找链表节点,空返回-1。 */
    ret = hash_find(mem_hash, key, &node_index);
    if(0 == ret)
    {
       // LOG_DEBUG("node is already exist");
    }
    else
    {
        /* 获取一个链表节点 */
        node_index = node_init(mem_hash, key, val);
        if(LIST_EMPTY == node_index)
        {
           // LOG_ERROR("node_init error");
            return -1;
        }

        /* 插入哈希表 */
        ret = hash_add(mem_hash, key, node_index);
        if(0 != ret)
        {
            /* 异常则回收链表节点 */
            node_release(mem_hash, node_index);
            return -1;
        }
    }

    return 0;
}

int mem_hash_delete(mem_hash_t *mem_hash, char *key, unsigned int key_size)
{
    int ret = -1;
    unsigned int node_index = 0;
    if(NULL == mem_hash || NULL == key)
    {
       // LOG_ERROR("param is NULL");
        return -1;
    }
    if(key_size != mem_hash->key_size)
    {
       // LOG_ERROR("size error, key_size:%u", key_size);
        return -1;
    }

    /* 从哈希表剔除链表节点 */
    ret = hash_delete(mem_hash, key, &node_index);
    if(0 != ret)
    {
       // LOG_ERROR("hash_delete error");
        return ret;
    }

    /* 回收链表节点 */
    node_release(mem_hash, node_index);

    return 0;
}

int mem_hash_delete_return(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size)
{
    int ret = -1;
    unsigned int node_index = 0;
    list_node_t *list_node = NULL;
    
    if(NULL == mem_hash || NULL == key || NULL == val)
    {
       // LOG_ERROR("param is NULL");
        return -1;
    }
    if(key_size != mem_hash->key_size || val_size != mem_hash->val_size)
    {
       // LOG_ERROR("size error, key_size:%u", key_size);
        return -1;
    }

    /* 从哈希表剔除链表节点 */
    ret = hash_delete(mem_hash, key, &node_index);
    if(0 != ret)
    {
       // LOG_ERROR("hash_delete error");
        return ret;
    }
    else
    {
        list_node = (list_node_t *)((char *)mem_hash + node_index);
        memcpy(val, (char *)mem_hash + list_node->val, mem_hash->val_size);
    }
    
    /* 回收链表节点 */
    node_release(mem_hash, node_index);

    return 0;
}

int mem_hash_find(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size)
{
    int ret = -1;
    unsigned int node_index = 0;
    list_node_t *list_node = NULL;

    if(NULL == mem_hash || NULL == key || NULL == val)
    {
       // LOG_ERROR("param is NULL");
        return -1;
    }
    if(key_size != mem_hash->key_size || val_size != mem_hash->val_size)
    {
       // LOG_ERROR("size error, key_size:%u, val_size:%u", key_size, val_size);
        return -1;
    }

    /* 从哈希表查找链表节点 */
    ret = hash_find(mem_hash, key, &node_index);
    if(0 != ret)
    {
       // LOG_ERROR("hash_find error");
        return ret;
    }
    else
    {
        list_node = (list_node_t *)((char *)mem_hash + node_index);
        memcpy(val, (char *)mem_hash + list_node->val, mem_hash->val_size);
        //printf("@@@val=[%s]\n",val);
    }

    return 0;
}

int mem_hash_find_val_index(mem_hash_t *mem_hash, char *key, unsigned int key_size, unsigned int *val_index)
{
    int ret = -1;
    unsigned int node_index = 0;
    list_node_t *list_node = NULL;

    if(NULL == mem_hash || NULL == key)
    {
       // LOG_ERROR("param is NULL");
        return -1;
    }
    if(key_size != mem_hash->key_size)
    {
       // LOG_ERROR("size error, key_size:%u", key_size);
        return -1;
    }

    /* 从哈希表查找链表节点 */
    ret = hash_find(mem_hash, key, &node_index);
    if(0 != ret)
    {
       // LOG_ERROR("hash_find error");
        return ret;
    }
    else
    {
        list_node = (list_node_t *)((char *)mem_hash + node_index);
        *val_index = list_node->val;
    }

    return 0;
}

int mem_hash_update(mem_hash_t *mem_hash, char *key, unsigned int key_size, char *val, unsigned int val_size)
{
    int ret = -1;
    unsigned int node_index = 0;
    list_node_t *list_node = NULL;

    if(NULL == mem_hash || NULL == key || NULL == val)
    {
       // LOG_ERROR("param is NULL");
        return -1;
    }
    if(key_size != mem_hash->key_size || val_size != mem_hash->val_size)
    {
       // LOG_ERROR("size error, key_size:%u, val_size:%u", key_size, val_size);
        return -1;
    }

    /* 从哈希表查找链表节点 */
    ret = hash_find(mem_hash, key, &node_index);
    if(0 != ret)
    {
       // LOG_ERROR("hash_find error");
        return ret;
    }
    else
    {
        list_node = (list_node_t *)((char *)mem_hash + node_index);
        memcpy((char *)mem_hash + list_node->val, val, mem_hash->val_size);
    }

    return 0;
}

int mem_hash_dump(mem_hash_t *mem_hash)
{
    int num = 0;
    int hash_num = 0;
    unsigned int current_index = 0;
    unsigned int next_index = 0;
    hash_node_t *hash_node_tmp = NULL;
    list_node_t *list_node_tmp = NULL;

    char *key = (char *)malloc(sizeof(char) * mem_hash->key_size);
    char *val = (char *)malloc(sizeof(char) * mem_hash->val_size);

    /* 遍历每一个哈希节点的存储位置 */
    for(hash_num = 0; hash_num < mem_hash->hash_size; hash_num++)
    {
        hash_node_tmp = (hash_node_t *)((char *)mem_hash + mem_hash->hash_head + sizeof(hash_node_t) * hash_num);
        current_index = hash_node_tmp->node_index;
        if(LIST_EMPTY == current_index)
        {
            continue;
        }
        else
        {
            while(LIST_EMPTY != current_index)
            {
                list_node_tmp = (list_node_t *)((char *)mem_hash + current_index);
                /* for test */
                memset(key, 0x00, sizeof(key));
                memset(val, 0x00, sizeof(val));
                memcpy(key, (char *)mem_hash + list_node_tmp->key, mem_hash->key_size);
                memcpy(val, (char *)mem_hash + list_node_tmp->val, mem_hash->val_size);
              //  LOG_ERROR("hash_num:%d, key:%s, val:%s", hash_num, key, val);

                current_index = list_node_tmp->next;
                num++;
            }
        }
    }

   // LOG_ERROR("num:%d", num);

    return 0;
}

mem_hash_iterator_t* mem_hash_get_iterator(mem_hash_t *mem_hash)
{
    hash_node_t *hash_node_tmp = NULL;
    hash_node_tmp = (hash_node_t *)((char *)mem_hash + mem_hash->hash_head);

    mem_hash_iterator_t *itr = (mem_hash_iterator_t *)malloc(sizeof(mem_hash_iterator_t));
    if(NULL == itr)
    {
      //  LOG_ERROR("mem_hash_iterator_t malloc error");
        return NULL;
    }

    itr->hash_num = 0;
    itr->node_next = hash_node_tmp->node_index;

    return itr;
}

void mem_hash_release_iterator(mem_hash_iterator_t *itr)
{
    if(NULL != itr)
    {
        free(itr);
    }
}

int mem_hash_next(mem_hash_t *mem_hash, mem_hash_iterator_t *itr, unsigned int *node_index)
{
    int ret = -1;
    unsigned int current_index = 0;
    hash_node_t *hash_node_tmp = NULL;
    list_node_t *list_node_tmp = NULL;

    if(NULL == mem_hash || NULL == itr || NULL == node_index)
    {
     //   LOG_ERROR("param is NULL");
        return -1;
    }

    current_index = itr->node_next;
    while(1)
    {
        //LOG_DEBUG("hash_num:%u, current_index:%u", itr->hash_num, current_index);
        if(LIST_EMPTY == current_index)
        {
            /* 下一个哈希链表 */
            itr->hash_num++;
            if(itr->hash_num >= mem_hash->hash_size)
            {
                break;
            }
            hash_node_tmp = (hash_node_t *)((char *)mem_hash + mem_hash->hash_head + sizeof(hash_node_t) * (itr->hash_num));
            current_index = hash_node_tmp->node_index;
        }
        else
        {
            /* 返回当前链表节点 */
            list_node_tmp = (list_node_t *)((char *)mem_hash + current_index);
            /* 迭代器指向下一个链表节点 */
            itr->node_next = list_node_tmp->next;
            
            break;
        }
    }

    //LOG_DEBUG("hash_num:%u, current_index:%u", itr->hash_num, current_index);
    if(itr->hash_num == mem_hash->hash_size && LIST_EMPTY == current_index)
    {
        //LOG_DEBUG("mem_hash fetch end");
        return -1;
    }
    else
    {
        *node_index = current_index;
        return 0;
    }
}


