#include "safe_string.h"


/**********************************************************************
* 函 数 名 : strupr
* 功能描述 : 字符串转换为大写
* 输入参数 : u_char *src 源字符串
*            size_t n 源字符串大小
*
* 输出参数 : u_char *dst 目标字符串
*
* 返 回 值 : ERR_SUCCESS 成功 
*            ERR_INIT_ERROR ERR_ERROR 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
void strupr(u_char *dst, u_char *src, size_t n)
{
    while (n) 
    {
        *dst = char_toupper(*src);
        dst++;
        src++;
        n--;
    }
}

/**********************************************************************
* 函 数 名 : strlow
* 功能描述 : 字符串转换为小写
* 输入参数 : u_char *src 源字符串
*            size_t n 源字符串大小
*
* 输出参数 : u_char *dst 目标字符串
*
* 返 回 值 : ERR_SUCCESS 成功 
*            ERR_INIT_ERROR ERR_ERROR 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
void strlow(u_char *dst, u_char *src, size_t n)
{
    while (n) 
    {
        *dst = char_tolower(*src);
        dst++;
        src++;
        n--;
    }
}

/**********************************************************************
* 函 数 名 : safe_strncpy
* 功能描述 : 字符串按长度拷贝，并在最后添加结束符
* 输入参数 : u_char *src 源字符串
*            size_t n 源字符串大小
*
* 输出参数 : u_char *dst 目标字符串
*
* 返 回 值 : ERR_SUCCESS 成功 
*            ERR_INIT_ERROR ERR_ERROR 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
char *safe_strncpy(char *dst, const char *src, size_t n)
{
    if(0 == n) 
    {
        return dst;
    }

    while(--n) 
    {
        *dst = *src;

        if(*dst == '\0')
        {
            return dst;
        }

        dst++;
        src++;
    }

    *dst = '\0';
    return dst;
}

/**********************************************************************
* 函 数 名 : safe_strcat
* 功能描述 : 源字符串拼接到目标字符串后面，并添加结束符，需保证目标串有足够的空间
* 输入参数 : u_char *src 源字符串
*            size_t n 源字符串大小
*
* 输出参数 : u_char *dst 目标字符串
*
* 返 回 值 : ERR_SUCCESS 成功 
*            ERR_INIT_ERROR ERR_ERROR 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
char *safe_strcat(char *dst, const char *src, size_t n)
{
    int len = 0;
    len = strlen(src) > n ? n : strlen(src);

    if(0 >= len)
    {
        return dst;
    }

    dst += strlen(dst);
    while(len)
    {
        *dst = *src;

        if(*dst == '\0')
        {
            return dst;
        }

        dst++;
        src++;
        len--;
    }

    *dst = '\0';
    return dst;
}

int replace_char(char *c_srcstr, int isrcstrLen, char* c_judgestr, int ijudgestrLen, char c_dst)
{
	int i, j;
    if (NULL == c_srcstr||NULL == c_judgestr)
	{
		return -1;
	}
    for(i=0 ; i <= (isrcstrLen-1); i++)
    {
        for( j = 0; j < ijudgestrLen ; j++)
        {
            if(c_srcstr[i] == c_judgestr[j] && c_srcstr[i+1] != c_judgestr[j])
            {
                c_srcstr[i] = c_dst;
                break;
            }
        }
    
    }
    return 0;
}

int replace_char_ex(char *c_srcstr, int isrcstrLen, char* c_judgestr, int ijudgestrLen, char* c_dst)
{
	int i, j;
    if (NULL == c_srcstr||NULL == c_judgestr)
	{
		return -1;
	}
    for(i=0 ; i <= (isrcstrLen-1); i++)
    {
        for( j = 0; j < ijudgestrLen ; j++)
        {
            if(c_srcstr[i] == c_judgestr[j] && c_srcstr[i+1] != c_judgestr[j])
            {
                c_srcstr[i] = c_dst[j];
                break;
            }
        }
    
    }
    return 0;
}


int remove_char(char * ch, char c)
{
    char *p = NULL;
    int i = 0;
    int j = 0;

    if(NULL == ch)
    {
        return -1;
    }
    p = ch;

    for(i=0,j=0;p[i] != '\0';i++)
    {
        if(p[i] != c)
        {
            p[j++] = p[i];
        }
    }
    p[j] = '\0';
    return 0;
}

unsigned int str2uint(char* pstr, unsigned int length)
{
	unsigned int dest = 0;
	u_char source[4] = {0};
	switch(length) {
	case 1:
		source[0] = (u_char)(*pstr);
		memcpy(&dest, source, sizeof(unsigned int));
		break;
	case 2:
		source[0] = (u_char)(*pstr);
		source[1] = (u_char)(*(pstr+1));
		memcpy(&dest, source, sizeof(unsigned int));
		break;
	case 3:
		source[0] = (u_char)(*pstr);
		source[1] = (u_char)(*(pstr+1));
		source[2] = (u_char)(*(pstr+2));
		memcpy(&dest, source, sizeof(unsigned int));
		break;
	case 4:
		source[0] = (u_char)(*pstr);
		source[1] = (u_char)(*(pstr+1));
		source[2] = (u_char)(*(pstr+2));
		source[3] = (u_char)(*(pstr+3));
		memcpy(&dest, source, sizeof(unsigned int));
//		ankki_printf("str2uint: dest=%d\n", dest);
		break;
	default:
		return -1;
	}
    return dest;
}

void trim_space(char* p, int length)
{
    int i;
    for(i = length - 1; i >= 0; i--)
    {
        if(p[i] != 0x20)
        {
            //0x20 -> space
            break;
        }
    }
    p[i + 1] = 0;
}

/**********************************************************************
* 函 数 名 : chars2uint
* 功能描述 : 将对应字节拷贝到int类型内存内取值
* 输入参数 : 
*            char* source 拷贝的源地址
              uint32_t length 拷贝长度
*
* 输出参数 : 无
*
* 返 回 值 : 失败为0 其他为内存里面的值
* 
* 修改历史 :
* 日     期  : 2018年9月20日
* 作     者  : hxd
* 修改内容 : 
* 
**********************************************************************/    
unsigned int chars2uint(char* source, unsigned int length)
{
    unsigned int value = 0;
    if (length > 4 || length < 0)
    {
        return 0;
    }

    memset(&value, 0x00, sizeof(unsigned int));
    memcpy(&value, source, length);

    return value;
}


