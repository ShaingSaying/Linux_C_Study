#include "shm_queue.h"

/**********************************************************************
* 函 数 名 : init_shm_queue
* 功能描述 : 初始化共享内存循环队列
* 输入参数 : shm_queue_t *shm_queue 共享内存队列
*            int shm_id 共享内存id
*            int queue_len 队列长度
*
* 输出参数 : 无
*
* 返 回 值 : 0 成功 
*            -1 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
int init_shm_queue(shm_queue_t *shm_queue, int shm_id, int queue_len)
{
    if(NULL == shm_queue || 0 >= shm_id || 0 >= queue_len)
    {
        LOG_ERROR("param error");
        return -1;
    }

    shm_queue->shm_id = shm_id;
    shm_queue->last_read_index = 0;
    __sync_lock_test_and_set(&(shm_queue->write_index), 0);
    __sync_lock_test_and_set(&(shm_queue->read_index), 0);
    shm_queue->queue_len = queue_len;
    //memset(shm_queue + sizeof(shm_queue_t), 0x00, shm_queue->queue_len);

    return 0;
}

int is_shm_queue_empty(shm_queue_t *shm_queue)
{
    return shm_queue->write_index == shm_queue->read_index ? 0 : -1;
}

int get_shm_queue_free_len(shm_queue_t *shm_queue)
{
    int free_len = 0;
    int write_index = shm_queue->write_index;
    int read_index = shm_queue->read_index;
    int queue_len = shm_queue->queue_len;

    free_len = write_index >= read_index ? (queue_len - write_index + read_index) : read_index - write_index;

    return free_len;
}

static int _enqueue_primitive(shm_queue_t *shm_queue, int *write_index, char *buff, int buff_len)
{
    int write_index_tmp;
    int tail_len = 0;
    char *queue_data = NULL;

    if(NULL == shm_queue || NULL == write_index || NULL == buff || 0 >= buff_len)
    {
        LOG_ERROR("param error");
        return -1;
    }

    /* 注意此处判断条件一定不能为0 */
    if (-1 == *write_index)
    {
        write_index_tmp = shm_queue->write_index;
    }
    else
    {
        write_index_tmp = *write_index; 
    }

    queue_data = (char *)shm_queue + sizeof(shm_queue_t);
    tail_len = shm_queue->queue_len - write_index_tmp;
    if(buff_len <= tail_len)
    {/* 直接存 */
        memcpy(queue_data + write_index_tmp, buff, buff_len);
    }
    else
    {/* 遇到队尾分两段存 */
        memcpy(queue_data + write_index_tmp, buff, tail_len);
        memcpy(queue_data, buff + tail_len, buff_len - tail_len);
        shm_queue->last_read_index = (write_index_tmp + buff_len) % shm_queue->queue_len;
    }

    *write_index = (write_index_tmp + buff_len) % shm_queue->queue_len;

    return 0;
}

static int _dequeue_primitive(shm_queue_t *shm_queue, int *read_index, char *buff, int buff_len)
{
    int read_index_tmp;
    int tail_len = 0;
    char *queue_data = NULL;

    if(NULL == shm_queue || NULL == read_index || NULL == buff || 0 >= buff_len)
    {
        LOG_ERROR("param error");
        return -1;
    }

    /* 注意此处判断条件一定不能为0 */
    if (-1 == *read_index)
    {
        read_index_tmp = shm_queue->read_index;
    }
    else
    {
        read_index_tmp = *read_index; 
    }

    queue_data = (char *)shm_queue + sizeof(shm_queue_t);
    tail_len = shm_queue->queue_len - read_index_tmp;
    if(buff_len <= tail_len)
    {/* 直接存 */
        memcpy(buff, queue_data + read_index_tmp, buff_len);
    }
    else
    {/* 遇到队尾分两段存 */
        memcpy(buff, queue_data + read_index_tmp, tail_len);
        memcpy(buff + tail_len, queue_data, buff_len - tail_len);
    }

	//长度归一化
    *read_index = (read_index_tmp + buff_len) % shm_queue->queue_len;

    return 0;
}


/**********************************************************************
* 函 数 名 : en_shm_queue
* 功能描述 : 写入共享内存循环队列
* 输入参数 : shm_queue_t *shm_queue 共享内存队列
*            char *buff 输出缓冲区
*            int *buff_len 读取内容长度
*
* 输出参数 : 无
*
* 返 回 值 : 0 成功 
*            -1 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
int en_shm_queue(shm_queue_t *shm_queue, char *buff, int buff_len)
{
    /* 初始条件应与_enqueue_primitive中的if条件一致且不能为0 */
    int write_index_tmp = -1;
    int free_len = 0;
    char s_len[LEN_LEN + 1];
    char *queue_data = NULL;

    if(NULL == shm_queue || NULL == buff || 0 >= buff_len)
    {
        LOG_ERROR("param error");
        return -1;
    }

    queue_data = (char *)shm_queue + sizeof(shm_queue_t);

/* 注释此处可以测试写共享队列的性能，正常测试请一定打开 */
#if 1
    free_len = get_shm_queue_free_len(shm_queue);
    /* 确保队列空间充足 */
    if(buff_len + LEN_LEN >= free_len)
    {
        LOG_FATAL("shm queue has no enough space, free_len:%d", free_len);
        return -1;
    }
#endif

    /* 记录待入队列的数据长度，便于出队列 */
    snprintf(s_len, sizeof(s_len), LEN_FORMAT, buff_len);

    /* 将数据元长度字符串先入队列 */
    if (0 != _enqueue_primitive(shm_queue, &write_index_tmp, s_len, LEN_LEN))
    {
        LOG_FATAL("enqueue data length error");
        return -1;
    }

    /* 继续将数据入队列 */
    if (0 != _enqueue_primitive(shm_queue, &write_index_tmp, buff, buff_len))
    {
        LOG_FATAL("enqueue data unit error");
        return -1;
    }

    /* 更新写索引 */
    __sync_lock_test_and_set(&(shm_queue->write_index), write_index_tmp);

    return 0;
}

/**********************************************************************
* 函 数 名 : de_shm_queue
* 功能描述 : 从共享内存循环队列读取内容
* 输入参数 : shm_queue_t *shm_queue 共享内存队列
*
* 输出参数 : char *buff 输出缓冲区
*            int *buff_len 读取内容长度
*
* 返 回 值 : 0 成功 
*            -1 失败
* 
* 修改历史 :
* 日     期  : 2018年7月25日
* 作     者  : hxw
* 修改内容 : 
* 
**********************************************************************/
int de_shm_queue(shm_queue_t *shm_queue, char *buff, int *buff_len)
{
    /* 初始条件应与_dequeue_primitive中的if条件一致且不能为0 */
    int read_index_tmp = -1;
    int tail_len = 0;
    char s_len[LEN_LEN + 1];
    int len = 0;
    char *queue_data = NULL;

    if(NULL == shm_queue)
    {
        LOG_ERROR("param error");
        return -1;
    }
    
    queue_data = (char *)shm_queue + sizeof(shm_queue_t);
    
    if(0 == is_shm_queue_empty(shm_queue))
    {
        LOG_ERROR("shm queue is empty");
        return -1;
    }

    memset(s_len, 0x00, sizeof(s_len));

    /* 先从队列中读出将出队的数据元长度 */
    if (0 != _dequeue_primitive(shm_queue, &read_index_tmp, s_len, LEN_LEN))
    {
        LOG_FATAL("dequeue data length error");
        return -1;
    }

    len = atoi(s_len);
    /* 继续将数据单元出队 */
    if (len <= 0 || 0 != _dequeue_primitive(shm_queue, &read_index_tmp, buff, len))
    {
        LOG_FATAL("dequeue data error, data length: %s", s_len);
        return -1;
    }

    __sync_lock_test_and_set(&(shm_queue->read_index), read_index_tmp);
    *buff_len = len;

    return 0;
}
