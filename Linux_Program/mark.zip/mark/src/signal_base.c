#include "signal_base.h"

/**********************************************************************
* 函 数 名 : register_signal
* 功能描述 : 注册新号
* 输入参数 : int32_t signo 信号
*            sigfunc *func 信号处理函数
*
* 输出参数 : 
*
* 返 回 值 : 成功 返回句柄
*            SIG_ERR 失败
*
* 修改历史 :
* 日     期 : 2018年9月18日
* 作     者 : hxw
* 修改内容 : 
*
**********************************************************************/
sigfunc *register_signal(int32_t signo, sigfunc *func)
{
    struct sigaction act, oact;
    act.sa_handler = func;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;

    if(sigaction(signo, &act, &oact))
    {
        return SIG_ERR;
    }

    return oact.sa_handler;
}

