#include "sock_stream.h"

extern int sock_err;

int netlink_socket(int netlink_protocol)
{
    return socket(AF_NETLINK, SOCK_RAW, netlink_protocol);
}

int netlink_bind(int fd)
{
    struct sockaddr_nl local;
    
    memset(&local, 0, sizeof(local));
    local.nl_family = AF_NETLINK;
    local.nl_pid = getpid();
    local.nl_groups = 0;
    if(0 != bind(fd, (struct sockaddr*)&local, sizeof(local)))
    {
        return -1;
    }
    return 0;
}

int netlink_recv(int fd, char *buff, int len)
{
    int rlen = 0;
    struct sockaddr_nl nladdr;
    struct msghdr msg;
	struct iovec iov;

    memset(&nladdr, 0x00, sizeof(struct sockaddr_nl));
    nladdr.nl_family = AF_NETLINK;
    nladdr.nl_pid = 0;
    nladdr.nl_groups = 0;
    
    memset(&msg, 0, sizeof(struct msghdr));
    msg.msg_name = (void *)&(nladdr);
    msg.msg_namelen = sizeof(struct sockaddr_nl);
    msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_iov->iov_base = buff;
	msg.msg_iov->iov_len = len;
	msg.msg_control = 0;
	msg.msg_controllen = 0;
	msg.msg_flags = 0;

    rlen = recvmsg(fd, &msg, MSG_WAITALL);

    return rlen;
}

/**********************************************************************
* 函 数 名 : netlink_recv_timeout
* 功能描述 : 接收netlink消息，超时返回
* 输入参数 : int32_t fd netlink套接字
*            char *buff 接收缓冲区
*            int32_t len 接收缓冲区长度
*            int32_t sec 超时时间
*
* 输出参数 : 无
* 返 回 值 : 成功 返回长度
*            失败 返回-1
* 
* 修改历史 :
* 日     期 : 2018年7月25日
* 作     者 : hxw
* 修改内容 : 
* 
**********************************************************************/
int32_t netlink_recv_timeout(int32_t fd, char *buff, int32_t len, int32_t sec)
{
    int32_t ret = -1;
    int32_t rlen = 0;
    fd_set rfds;
    struct timeval tv;

    FD_ZERO(&rfds);
    FD_SET(fd, &rfds);
    tv.tv_sec = sec;
    tv.tv_usec = 0;
    
    ret = select(fd + 1, &rfds, NULL, NULL, &tv);
    switch(ret)
    {
        case -1:
        {
            LOG_ERROR("select error:%s", strerror(errno));
        }
        break;

        case 0:
        {
            LOG_ERROR("select timeout");
        }
        break;

        default:
        {
            if(FD_ISSET(fd, &rfds))
            {
                memset(buff, 0x00, len);
                rlen = netlink_recv(fd, buff, len);
                if(0 > rlen)
                {
                	return -1;
                }
                else
                {
                    return rlen;
                }
            }
            else
            {
                LOG_ERROR("unrecognize");
            }
        }
        break;
    }

    return -1;
}

int netlink_send(int fd, data_to_kernel_t *data, int len)
{
    int slen = 0;
    struct sockaddr_nl nladdr;
    struct msghdr msg;
	struct iovec iov;

    memset(&nladdr, 0x00, sizeof(struct sockaddr_nl));
    nladdr.nl_family = AF_NETLINK;
    nladdr.nl_pid = 0;
    nladdr.nl_groups = 0;

    memset(&msg, 0, sizeof(struct msghdr));
    msg.msg_name = (void *)&(nladdr);
    msg.msg_namelen = sizeof(struct sockaddr_nl);
    msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_iov->iov_base = &(data->hdr);
	msg.msg_iov->iov_len = data->hdr.nlmsg_len;
	msg.msg_control = 0;
	msg.msg_controllen = 0;
	msg.msg_flags = 0;
    
    slen = sendmsg(fd, &msg, 0);
    return slen;
}


int create_ipv4_socket()
{
    return socket(AF_INET, SOCK_STREAM, 0);
}

int create_un_socket()
{
    return socket(AF_LOCAL, SOCK_STREAM, 0);
}

int tcp_server_socket(int port, int *sock)
{
    int fd = 0;
    struct sockaddr_in serv_addr;

    //socket
    fd = create_ipv4_socket();
    if(0 >= fd)
    {
        LOG_ERROR("socket error");
        return -1;
    }

    memset(&serv_addr, 0x00, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(port);

    //bind
    if(-1 == bind(fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)))
    {
        LOG_ERROR("bind error");
        return -1;
    }

    //listen
    if(-1 == listen(fd, 5))
    {
        LOG_ERROR("listen error");
    }

    *sock = fd;
    
    return 0;
}

int tcp_accept(int fd)
{
    int accept_fd = 0;
    socklen_t socketadd_len = 0;
    struct sockaddr_in clnt_addr;
    
    socketadd_len = sizeof(clnt_addr);
    accept_fd = accept(fd, (struct sockaddr *)&clnt_addr, &socketadd_len);
    if(0 >= accept_fd)
    {
        LOG_DEBUG("accept error:%s", strerror(errno));
        return -1;
    }
    else
    {
        LOG_DEBUG("accept success, accept_fd:%d", accept_fd);
    }

    return accept_fd;
}


/**********************************************************************
* 函 数 名 : tcp_recv
* 功能描述 : 按长度接收数据
* 输入参数 : 
*
* 输出参数 : 无
* 返 回 值 : 成功 返回长度
*            失败 返回0
* 
* 修改历史 :
* 日     期 : 2018年7月25日
* 作     者 : hxw
* 修改内容 : 
* 
**********************************************************************/
int tcp_recv(int fd, char *buf, int len)
{
    int ret = 0;
    int rlen;
    int err;
    if (0 >= len)
    {
        LOG_ERROR("len error");
        return 0;
    }
    
    while (1)
    {
        rlen = recv(fd, buf + ret, len - ret, 0);
        if (0 == rlen)
        {
            LOG_ERROR("recv data lenth = 0, connection closed, fd:%d", fd);
            ret = 0;
            break;
        }
        else if (0 > rlen)
        {
            err = errno;
            if (err == EINTR)
            {
                continue;
            }
            else if (err == EAGAIN || err == EWOULDBLOCK)
            {
                LOG_DEBUG("errno == EAGAIN");
                break;
            }
            else
            {
                LOG_ERROR("recv data error: ret = %d, err = %s, fd:%d", rlen, strerror(err), fd);
                break;
            }
        }

        ret += rlen;
        if (ret == len)
        {
            break;
        }
    }

    return ret;
}

int tcp_send(int fd, char *buf, int len)
{
    int ret = 0;
    int slen = 0;
    
    if (len <= 0)
    {
        return 0;
    }
    
    while (1)
    {
        slen = send(fd, buf + ret, len - ret, 0);
        if (slen < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }
            else if (errno == EAGAIN || errno == EWOULDBLOCK)
            {
                LOG_WARN("tcp_send:EAGAIN, fd:%d len:%d", fd, len);
                break;
            }
            else
            {
                LOG_ERROR("send data error: slen:%d, err:%s, fd:%d", slen, strerror(errno), fd);
                //sock_err = SOCK_ERR_OTHER;
                break;
            }
        }

        ret += slen;
        if (ret == len)
        {
            break;
        }
    }

    return ret;
}


int set_nonblock(int fd)
{
    int opts;
    opts = fcntl(fd, F_GETFL);
    if (opts < 0)
    {
        LOG_WARN("fcntl F_GETFL failed, fd:%d", fd);
        return -1;
    }

    opts = opts | O_NONBLOCK;
    if (fcntl(fd, F_SETFL, opts) < 0)
    {
        LOG_WARN("fcntl F_SETFL failed, fd:%d", fd);
        return -1;
    }

    return 0;
}

