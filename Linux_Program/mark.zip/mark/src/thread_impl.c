#include "thread_impl.h"


int pthread_create_detached(pthread_t* handle, void *(*func)(void*), void *param)
{
    int ret = -1;	
	pthread_attr_t attr;

    if(NULL == func || handle == NULL)
	{
		return -1;
	}

	pthread_attr_init(&attr);	
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	ret = pthread_create(handle, &attr, func, param);
    if(0 != ret)
    {
        return -1;
    }
    pthread_attr_destroy(&attr);
    
    return 0;
}

