#include "shm_base.h"
#include "mem_hash.h"

/* 哈希节点个数 */
#define MEM_SIZE (128*1024)
#define IPADDR_KEY_SIZE 16
#define MACADDR_VAL_SIZE 18
/* 链表节点大小 */
#define MACADDR_LIST_NODE_SIZE (sizeof(list_node_t) + IPADDR_KEY_SIZE + MACADDR_VAL_SIZE)
/* 哈希表总大小 */
#define MACADDR_MEM_SIZE  (sizeof(mem_hash_t) + (sizeof(hash_node_t) + MACADDR_LIST_NODE_SIZE) * MEM_SIZE)

char *mem_hash;
/* 一个进场添加更新 */
/* 一个进场读取数据 */
int create_shm_hash()
{
    int shmid = 0;
    int ret = 0;

    shmid = gen_shm("/.mac_address", MACADDR_MEM_SIZE);
    if(-1 == shmid)
    {
        printf("gen_shm error\n");
        return -1;
    }

    ret = attach_shm(shmid, (void **)&mem_hash);
    if(0 != ret)
    {
        printf("attach_shm error\n");
        return -1;
    }

    ret = mem_hash_init((mem_hash_t *)(mem_hash), MACADDR_MEM_SIZE, MEM_SIZE, IPADDR_KEY_SIZE, MACADDR_VAL_SIZE);
    if(0 != ret)
    {
        printf("mem_hash_init error\n");
        return -1;
    }

    return 0;
}

int childpid()
{
    char val[MACADDR_VAL_SIZE]={0};
    int ret = 0;

    printf("val = [%s]\n");
    ret = mem_hash_find((mem_hash_t *)mem_hash, "172.024.001.106", IPADDR_KEY_SIZE, val, MACADDR_VAL_SIZE);
    if(ret != 0)
    {
        printf("mem_hash_find error\n");
        return -1;
    }
    else
    {
        printf("val = [%s]\n",val);
    }
    
    memset(val, 0x00, sizeof(val));

    sleep(30);
    printf("val=[%s]\n",val);

    ret = mem_hash_find((mem_hash_t *)mem_hash, "172.024.001.106", IPADDR_KEY_SIZE, val, MACADDR_VAL_SIZE);
    if(ret != 0)
    {
        printf("mem_hash_find error\n");
        return -1;
    }
    else
    {
        printf("val = [%s]\n",val);
    }
    
    return 0;    
}
int main()
{
    int ret = 0;
    pid_t child_pid;
    int stat_val;
    char val[MACADDR_VAL_SIZE]={0};
    ret = create_shm_hash();
    printf("ret = %d\n",ret);

    ret = mem_hash_add_ifnotexist((mem_hash_t *)mem_hash, "172.024.001.106", IPADDR_KEY_SIZE, "4c:cc:6a:87:44:f2", MACADDR_VAL_SIZE);
    if(ret != 0)
    {
        printf("mem_hash_add_ifnotexist error\n");
        return -1;
    }
    ret = mem_hash_add_ifnotexist((mem_hash_t *)mem_hash, "172.024.001.116", IPADDR_KEY_SIZE, "4c:cc:6a:87:44:f3", MACADDR_VAL_SIZE);
    if(ret != 0)
    {
        printf("mem_hash_add_ifnotexist error\n");
        return -1;
    }
    ret = mem_hash_add_ifnotexist((mem_hash_t *)mem_hash, "172.024.001.206", IPADDR_KEY_SIZE, "4c:cc:6a:87:44:f4", MACADDR_VAL_SIZE);
    if(ret != 0)
    {
        printf("mem_hash_add_ifnotexist error\n");
        return -1;
    }

    child_pid = fork();
    switch(child_pid)
    {
        case -1 :
            break;
        case 0  :
            //sleep(2);
            childpid();
            return 0;
        default:
            break;
    }

    ret = mem_hash_update((mem_hash_t *)mem_hash, "172.024.001.106", IPADDR_KEY_SIZE, "4c:cc:6a:87:44:gg", MACADDR_VAL_SIZE);
    if(ret != 0)
    {
        printf("mem_hash_update error\n");
        return -1;
    }

    ret = mem_hash_find((mem_hash_t *)mem_hash, "172.024.001.106", IPADDR_KEY_SIZE, val, MACADDR_VAL_SIZE);
    if(ret != 0)
    {
	printf("mem_hash_find error\n");
        return -1;
    }
    printf("parent val==[%s]\n",val);

    write(&stat_val);
    return 0;
}
