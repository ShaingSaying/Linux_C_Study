#include "include/shm_base.h"
#include "include/shm_queue.h"

shm_queue_t *record_shm_queue;

int parent_shm_queue()
{
    char file_name[256];
    int index = 1;
    int shmid = 0;
    int shm_len = 2048;
    int ret = -1;

    memset(file_name, 0x00, sizeof(file_name));
    snprintf(file_name, sizeof(file_name), "/.hello.%d", index);
    shmid = gen_shm(file_name, sizeof(shm_queue_t) + shm_len);
    if(-1 == shmid)
    {
        printf("gen_shm error\n");
        return -1;
    }
    ret = attach_shm(shmid, (void **)&record_shm_queue);
    if(0 != ret)
    {
        printf("attach_shm error\n");
        return -1;
    }

    ret = init_shm_queue(record_shm_queue, shmid, shm_len);
    printf("init shm_queue success\n");
    return 0;
}
int child_shm()
{

}
void child_pid()
{
    int buff_len;
    char buff[256];
    printf("into child_pid\n");
    for(int i = 0; i < 100; i++)
    {
        memset(buff, 0x00, sizeof(buff));
        if(de_shm_queue(record_shm_queue, buff, &buff_len) < 0)
        {
            printf("shm empty, no packet(s)");
            usleep(500000);
            continue;
        }
        buff[buff_len] = 0;
        printf("child[%d]read buff[%s]\n",getpid(),buff);
        //sleep(1);
    }

}
int main()
{
    pid_t parent;
    char buff[256];

    parent_shm_queue();

    parent = fork();
    switch(parent)
    {
        case: -1
            break;
        case: 0
            sleep(2);
            child_pid();
            return 0;
        default:
            break;
    }

    for(int i = 0; i < 100; i++)
    {
        memset(buff, 0x00, sizeof(buff));
        snprintf(buff, sizeof(buff), "hello[%d]", i);
        buff_len = strlen(buff);
        en_shm_queue(record_shm_queue, buff, buff_len);
        //sleep(1);
    }

    return 0;
}