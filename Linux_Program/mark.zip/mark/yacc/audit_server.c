/*

  snapper

  Created by Varun Singh on 10/3/2012.
  Custmized by RaL on 11/09/2017


 Note a lot of code is borrowed from here and there.

 gcc -Wall -pedantic snapper.c -lpcap -o snapper
 http://www.tcpdump.org/pcap.html
 http://tools.ietf.org/html/rfc793
 http://tools.ietf.org/html/rfc1071

 Tested to run on the MAC.

 The TCP reset packets (TCP RST) are sent when the utility sees ACK packets. 
 */

#define APP_NAME        "snapper"
#define APP_DESC        "based on Sniffer example using libpcap"

#if 0
#define APP_COPYRIGHT   "extended by Varun Singh / Copyright (c) 2005 The Tcpdump Group"
#define APP_DISCLAIMER  "THERE IS ABSOLUTELY NO WARRANTY FOR THIS PROGRAM.\n"
#endif
#define APP_COPYRIGHT   "extended by Ral / Copyright (c) 2017"
#define APP_DISCLAIMER  "\r"

#include <pcap.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>
#include <signal.h>
#include <unistd.h> 
#include <getopt.h>

/* added by lx for unique running */
#include <fcntl.h>
#include <syslog.h>
#include <sys/stat.h>
//#include "../bs_audit/include/global_all.h"
#include "../bs_audit/include/checklic.h"


int print_door_flag = 1;
//extern int checkDBTypeAuthorize(char* dbType);
#if 0
#define __USE_BSD         /* Using BSD IP header           */ 
#endif
#include <netinet/ip.h>   /* Internet Protocol             */ 
#define __FAVOR_BSD       /* Using BSD TCP header          */ 
#include <netinet/tcp.h>  /* Transmission Control Protocol */

/* added by lx for unique running */
//#define LOCKMODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)

/* default snap length (maximum bytes per packet to capture) */
#define SNAP_LEN 1518

/* ethernet headers are always exactly 14 bytes [1] */
#define ETHHDRSIZE 14

/* Ethernet addresses are 6 bytes */
//#define ETHER_ADDR_LEN  6

#define VLANHDRSIZE sizeof(struct sniff_vlan)

/* IPv4, TCP, IP+TCP header sizes */
#define IPHDRSIZE sizeof(struct sniff_ip)
#define TCPHDRSIZE sizeof(struct sniff_tcp)
#define IPTCPHDRSIZE (sizeof(struct sniff_ip) + sizeof(struct sniff_tcp))

/* INET_ADDRSTRLEN is 16 */

#define HOME_IP ""
/*
This should be autodetected...
*/

#define CAPTURE_COUNT -1          /* number of packets to capture, -1: non-stop */

/* filter_exp array size */
#define EXPSIZE 4096

#define BUFSIZE 100
#define IP_STR_SIZE 16
#define DEFAULT_RUNNING_TIME 30 /* seconds */
#define SNAPPER_PID_DIR "/home/audit/snapper_pid"

#if _DEBUG
#define ankki_printf(fmt, args...) \
        printf("[Func:%s][Line:%d]\n"fmt"", __func__, __LINE__, ##args)
#else
//#define ankki_printf(fmt, args...)
#endif


/* global file name have self pid in store */
char g_pid_file[BUFSIZE];
char g_pid_file_flag[BUFSIZE];
/* global file description to open pid_file */
int g_uniq_fd = 0;

/* Ethernet header */
struct sniff_ethernet {
    u_char  ether_dhost[ETHER_ADDR_LEN];    /* destination host address */
    u_char  ether_shost[ETHER_ADDR_LEN];    /* source host address */
    u_short ether_type;                     /* IP? ARP? RARP? etc */
};

/*
+--------+--------+--------+--------+--------+--------+--------+--------+
|         vlan-PRI         |vlan-CFI|                                   |
+--------+--------+--------+--------+               ether               +
|                VLAN               |                                   |
+        +        +        +        +                type               +
|                TAG                |                                   |
+        +        +        +        +               in vlan             +
|                 ID                |                                   |
+--------+--------+--------+--------+--------+--------+--------+--------+
*/
/* Ethernet addresses are 6 bytes */
struct sniff_vlan {
	u_short vlan;
		/* pri:3, cfi:1, vlan_id:12; */    /* 3-bit before is PRI, the last 1-bit is CFI */
	                            /* 12-bit vlan tag id */
	u_short ether_type_in_vlan; /* sub ether type */
};

#if 0	 /* alternative padding in the end of ip packet */
struct sniff_vlan_tail {
    u_char *padding;
    u_char *trailer;
};
#endif


/* 
IP header: http://tools.ietf.org/html/rfc791#section-3.1

     0                   1                   2                   3
     0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |Version|  IHL  |Type of Service|          Total Length         |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |         Identification        |Flags|      Fragment Offset    |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |  Time to Live |    Protocol   |         Header Checksum       |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |                       Source Address                          |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |                    Destination Address                        |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |                    Options                    |    Padding    |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     */

struct sniff_ip {
    u_char  ip_vhl;               /* version << 4 | header length >> 2 */
    u_char  ip_tos;               /* type of service */
    u_short ip_len;               /* total length */
    u_short ip_id;                /* identification */
    u_short ip_off;               /* fragment offset field */
    #define IP_RF 0x8000            /* reserved fragment flag */
    #define IP_DF 0x4000            /* dont fragment flag */
    #define IP_MF 0x2000            /* more fragments flag */
    #define IP_OFFMASK 0x1fff       /* mask for fragmenting bits */
    u_char  ip_ttl;               /* time to live */
    u_char  ip_p;                 /* protocol */
    u_short ip_sum;               /* checksum */
    struct  in_addr ip_src,ip_dst;/* source and dest address */
};
#define IP_HL(ip)               (((ip)->ip_vhl) & 0x0f)
#define IP_V(ip)                (((ip)->ip_vhl) >> 4)

/* device */
struct bpf_program fp;          /* compiled filter program (expression) */
char cnet[INET_ADDRSTRLEN];     /* dot notation of the network address */
bpf_u_int32 net;                /* network address */
char cmask[INET_ADDRSTRLEN];    /* dot notation of the network mask    */
bpf_u_int32 mask;               /* subnet mask */
pcap_t *handle;                 /* packet capture handle */
int pkt_count = 1;              /* packet counter */



/* 
TCP header: http://tools.ietf.org/html/rfc793#section-3.1

     0                   1                   2                   3
     0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |          Source Port          |       Destination Port        |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |                        Sequence Number                        |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |                    Acknowledgment Number                      |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |  Data |           |U|A|P|R|S|F|                               |
     | Offset| Reserved  |R|C|S|S|Y|I|            Window             |
     |       |           |G|K|H|T|N|N|                               |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |           Checksum            |         Urgent Pointer        |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |                    Options                    |    Padding    |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |                             data                              |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

*/
typedef u_int tcp_seq;

struct sniff_tcp {
    u_short th_sport;       /* source port */
    u_short th_dport;       /* destination port */
    tcp_seq th_seq;         /* sequence number */
    tcp_seq th_ack;         /* acknowledgement number */
    u_char  th_offx2;       /* data offset, rsvd */
    #define TH_OFF(th)      (((th)->th_offx2 & 0xf0) >> 4)
    u_char  th_flags;
    #define TH_FIN  0x01    /* 1  */
    #define TH_SYN  0x02    /* 2  */
    #define TH_RST  0x04    /* 4  */
    #define TH_PUSH 0x08    /* 8  */
    #define TH_ACK  0x10    /* 16 */
    #define TH_URG  0x20    /* 32 */
    #define TH_ECE  0x40    /* 64 */
    #define TH_CWR  0x80    /* 128*/
    #define TH_FLAGS        (TH_FIN|TH_SYN|TH_RST|TH_ACK|TH_URG|TH_ECE|TH_CWR)
    u_short th_win;         /* window */
    u_short th_sum;         /* checksum */
    u_short th_urp;         /* urgent pointer */
};

/* 
Pseudoheader (Used to compute TCP checksum. from RFC793) The checksum
also covers a 96 bit pseudo header conceptually prefixed to the TCP
header. This pseudo header contains the Source Address, the Destination
Address, the Protocol, and TCP length. This gives the TCP protection
against misrouted segments. This information is carried in the Internet
Protocol and is transferred across the TCP/Network interface in the
arguments or results of calls by the TCP on the IP.
+--------+--------+--------+--------+
|           Source Address          |
+--------+--------+--------+--------+
|         Destination Address       |
+--------+--------+--------+--------+
|  zero  |  PTCL  |    TCP Length   |
+--------+--------+--------+--------+
*/
struct pseudo_hdr {
    u_int32_t src;     /* 32bit source ip address*/
    u_int32_t dst;     /* 32bit destination ip address */  
    u_char zero;       /* 8 reserved bits (all 0)  */
    u_char protocol;   /* protocol field of ip header */
    u_int16_t tcplen;  /* tcp length (both header and data */
};


static void got_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet);

#if NOT_CMD
static void print_app_banner(void);
#endif

static void print_app_usage(void);

static void readTCPflag(u_char tcp_flags);

static void showPacketDetails(const struct sniff_ip *iph, const struct sniff_tcp *tcph);

static void ParseTCPPacket(const u_char *packet);

static void createRSTpacket(struct in_addr srcip, struct in_addr destip, u_short sport, u_short dport,
                            u_short ident, unsigned int seq, u_char ttl, unsigned int ack);

/* added by lx for unique running */
static int lock_file(int fd);

static int already_running(char *pid_file);


#if NOT_CMD
static void print_app_banner(void)
{

    printf("%s - %s\n", APP_NAME, APP_DESC);
    printf("%s\n", APP_COPYRIGHT);
    printf("%s\n", APP_DISCLAIMER);
    printf("\n");

    return;
}
#endif

/* 
Copy pasted the code from the interwebs. Outputs of in_cksum() and
checksum_comp() are equivalent, but note that in checksum_comp() we
transform the checksum using htons() before returning the value.

 Read: http://tools.ietf.org/html/rfc1071 for the algorithm
 */

unsigned short in_cksum(unsigned short *addr,int len){
    register int sum = 0;
    u_short answer = 0;
    register u_short *w = addr;
    register int nleft = len;

    /*
    * Our algorithm is simple, using a 32-bit accumulator (sum),
    * we add sequential 16-bit words to it, and at the end, fold back 
    * all the carry bits from the top 16 bits into the lower 16 bits. 
    */

    while (nleft > 1) {
        sum += *w++;
        nleft -= 2;
    }

    /* mop up an odd byte, if necessary */
    if (nleft == 1) {
        *(u_char *)(&answer) = *(u_char *) w;
        sum += answer;
    }

    /* add back carry outs from top 16 bits to low 16 bits */
    sum = (sum >> 16) + (sum &0xffff); /* add hi 16 to low 16 */
    sum += (sum >> 16); /* add carry */
    answer = ~sum; /* truncate to 16 bits */
    return(answer);

}


static void signal_handler_alarm(int signal)
{
    /* cleanup */
#ifndef NOT_CMD
	ankki_printf("\nreceive alarm signal, exit by self\n");
    if (g_uniq_fd)
    {
        close(g_uniq_fd);
	}
    unlink(g_pid_file);
	unlink(g_pid_file_flag);
#endif
    pcap_freecode(&fp);
    pcap_close(handle);

    ankki_printf("\nGoodbye!!\n"); 
    exit(0);
}


static void signal_handler(int signal)
{
    /* cleanup */
#ifndef NOT_CMD
    if (g_uniq_fd)
    {
        close(g_uniq_fd);
	}
    unlink(g_pid_file);
	unlink(g_pid_file_flag);
#endif
    pcap_freecode(&fp);
    pcap_close(handle);

    ankki_printf("\nGoodbye!!\n"); 
    exit(0);
}

#if NOT_CMD
static void print_app_usage(void)
{

    printf("Usage: %s [interface] [filter]\n", APP_NAME);
    printf("\n");
    printf("Options:\n");
    printf("    interface     Listen on <interface> for packets.\n");
    printf("    filter        PCAP Filter to apply on packets.\n");
    printf("\n");
    printf("*\n");
    printf("* Expression	 	    Description\n"); 
    printf("*----------			    -----------\n");
    printf("* ip					Capture all IP packets.\n");
    printf("* tcp			        Capture only TCP packets.\n");
    printf("* tcp port 80			Capture only TCP packets with a port equal to 80.\n");
    printf("* ip host 10.1.2.3		Capture all IP packets to or from host 10.1.2.3.\n");
    printf("*\n");
    printf("****************************************************************************\n");
    printf("*   tcp[13] == 0x10) or (tcp[13] == 0x18) for ACK and ACK+PUSH\n");
    printf("*  (tcp[13] == 0x10) for only ACK packets\n");
    printf("*  ip for any IP packet\n");
    printf("*\n");

    return;
}
#else
static void print_app_usage(void)
{
    printf("\nUsage: snapper [-dDisSt] -i interface [-d dst ipaddr] [-D dst port] \
		[-s src ipaddr] [-S src port] [-t time] [-h help]\n");
    printf("Options:\n");
    printf("-i  --interface    choose a netcard interface\n");
    printf("-d  --dst          destination ip address\n");
    printf("-D  --dstport      destination port\n");
    printf("-s  --src          source ip address\n");
    printf("-S  --srcport      source port\n");
	printf("-t  --time         keep running time\n");
	printf("-h  --help         help information\n");
    printf("(For example: snapper -i eth0 -d 192.168.1.1 -D 21 -s 192.168.1.254 -S 55555)\n\n");
}
#endif


/* added by lx for unique running */
static int lock_file(int fd)
{
	struct flock fl;

	fl.l_type = F_WRLCK;
	fl.l_start = 0;
	fl.l_whence = SEEK_SET;
	fl.l_len = 0;

	return (fcntl(fd, F_SETLK, &fl));
}

static int already_running(char *pid_file)
{
	char pid_str[8];
	char *w_ptr = pid_str;
	/* write Byte per time */
	ssize_t w_num = 0;
	/* already write total Bytes*/
	ssize_t t_num = 0;
	ssize_t pid_len;
	/* to tell other process pid writing is finished */
	snprintf(g_pid_file_flag, BUFSIZE, "%s-wf", pid_file);

	memset(pid_str, '\0', 8);
	snprintf(pid_str, 8, "%u", getpid());
	pid_len = strlen(pid_str);

	g_uniq_fd = open(pid_file, O_RDWR | O_CREAT, LOCKMODE);
	if (g_uniq_fd < 0)
	{
		fprintf(stderr, "can't open %s: %s\n", pid_file, strerror(errno));
		exit(1);
	}
	/* set write file lock and dont release */
	if (lock_file(g_uniq_fd) < 0)
	{
		if (errno == EACCES || errno == EAGAIN)
		{
			close(g_uniq_fd);
			return 1;
		}
		fprintf(stderr, "can't lock %s: %s\n", pid_file, strerror(errno));
		exit(1);
	}

	/* record the pid into the file */
	while (t_num < pid_len && (w_num = write(g_uniq_fd, w_ptr, pid_len)))
	{
		if (w_num < 0)
		{
			ankki_printf("write failed\n");
			close(g_uniq_fd);
			return -1;
		}
		else
		{
			if (w_num > 0)
			{/* write successfully */
				t_num += w_num;
				w_ptr += w_num;
				ankki_printf("\nt_num = %d,\tw_num = %d\n", (int)t_num, (int)w_num);
			}
			else
			{/* write end */
				ankki_printf("\nWrite END::t_num = %d,\tw_num = %d\n", (int)t_num, (int)w_num);
			}
		}
	}
	/*
	close(g_uniq_fd); // this one shouldn't be closed because the lock would be lost
	*/

	/* create a XXX-wf file to tell other process pid write finished */
	ankki_printf("create write flag file\n");
	if (creat(g_pid_file_flag, 0644) < 0)
	{
		fprintf(stderr, "can't open %s: %s\n", pid_file, strerror(errno));
		return -1;
	}
	ankki_printf("create write flag file successfully\n");

	return 0;
}

/*
 * dissect/print packet
 */
static void got_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet)
{
    const struct sniff_ethernet *ethernet;  /* The ethernet header [1] */
	const struct sniff_vlan *vh;            /* vlan header */
    const struct sniff_ip *ip;              /* The IP header */
    int size_ip;
    char srcHost[INET_ADDRSTRLEN];
    char dstHost[INET_ADDRSTRLEN];
	unsigned short eth_type;

    /* define ethernet header */
    ethernet = (struct sniff_ethernet*)(packet);

	switch(eth_type = ntohs(ethernet->ether_type)) {
		case ETH_P_IP:
		ankki_printf("IP:\n");
	    /* define/compute ip header offset */
        ip = (struct sniff_ip*)(packet + ETHHDRSIZE);
		break;
		case ETH_P_8021Q:
		ankki_printf("VLAN:\t");
		vh = (struct sniff_vlan*)(packet + ETHHDRSIZE);
		if ((eth_type = ntohs(vh->ether_type_in_vlan)) == ETH_P_IP) {
			ankki_printf("IP:\n");
			ip = (struct sniff_ip*)(packet + ETHHDRSIZE + VLANHDRSIZE);
		}
		else {
			ankki_printf("unknown ether type: %x\n", eth_type);
			return;
		}
		break;
		default:
		ankki_printf("unknown ether type: %x\n", eth_type);
		return;
		break;
	}

    size_ip = IP_HL(ip)*4;
    /* less than < originally */
    if (size_ip < IPHDRSIZE) {
        ankki_printf("   * Invalid IP header length: %u bytes\n", (unsigned int)size_ip);
        return;
    }

    strncpy(srcHost, inet_ntoa(ip->ip_src), INET_ADDRSTRLEN);
    strncpy(dstHost, inet_ntoa(ip->ip_dst), INET_ADDRSTRLEN);
    ankki_printf("P%d:\t", pkt_count++);
    ankki_printf("%s\t->\t", srcHost);
    ankki_printf(" %s\t", dstHost);

    switch(ip->ip_p) {
        case IPPROTO_TCP:
        ankki_printf("TCP\t");
        ParseTCPPacket((u_char *)ip);
        break;
        case IPPROTO_UDP:
        ankki_printf("UDP\t");
        break;
        case IPPROTO_ICMP:
        ankki_printf("ICMP\t");
        break;
        case IPPROTO_IP:
        ankki_printf("IP\t");
        break;
        default:
        ankki_printf("Protocol: unknown\t");
        break;
    }
    ankki_printf("\n");
}

static void ParseTCPPacket(const u_char *packet)
{
    const struct sniff_ip *ip;              /* The IP header */
    const struct sniff_tcp *tcp;            /* The TCP header */

    int size_ip = 0;
    int size_tcp;

#if _DEBUG
    const u_char *payload;                  /* Packet payload */
    int size_payload;
#endif

    unsigned int srcport;
    unsigned int dstport;

    ip = (struct sniff_ip*)(packet);

    /* leave a custmize selection for some purpose by lx */
    /*if((strcmp(srcHost, HOME_IP)==0)|| (strcmp(dstHost, HOME_IP)==0))*/
    {
        /* define/compute tcp header offset */
        tcp = (struct sniff_tcp*)(packet + IPHDRSIZE);
        size_tcp = TH_OFF(tcp)*4;
        /* less than < originally */
        if (size_tcp < TCPHDRSIZE) {
            ankki_printf("   * Invalid TCP header length: %u bytes\n", (unsigned int)size_tcp);
            return;
        }
        srcport = ntohs(tcp->th_sport);
        dstport = ntohs(tcp->th_dport);

#if _DEBUG
        /* define/compute tcp payload (segment) offset */
        payload = (u_char *)(packet + IPHDRSIZE + TCPHDRSIZE);

        /* compute tcp payload (segment) size */
        size_payload = ntohs(ip->ip_len) - (size_ip + size_tcp);

        ankki_printf("%d\t->\t", srcport);
        ankki_printf(" %d\t", dstport);
        ankki_printf("id: %d\t", htons(ip->ip_id));
        ankki_printf("seq: %u\t", ntohl(tcp->th_seq));  
        ankki_printf("ack: %u\t", ntohl(tcp->th_ack));  
        ankki_printf("sum: %x\n", (ip->ip_sum));
		ankki_printf("payload: %p\n", payload);

        /* can be commented if not debug */
        if (size_payload > 0) {
            printf("   Payload (%d bytes)", size_payload);
        }
#endif


        /*printf("Sniffed Packet Header\n");*/
        showPacketDetails(ip, tcp); 

        /*
        Create spurious RST packet
        Send the ACK number as sequence number to the source
        Send the incremented SEQ to the target

        if (tcph->th_flags & TH_ACK)        
        */

        /* send rst packet in both direction surely terminate the connection*/
        createRSTpacket(ip->ip_dst, ip->ip_src, tcp->th_dport, tcp->th_sport, ip->ip_id, tcp->th_ack, ip->ip_ttl, tcp->th_ack);
        createRSTpacket(ip->ip_src, ip->ip_dst, tcp->th_sport, tcp->th_dport, ip->ip_id, htonl(ntohl(tcp->th_seq)+1), ip->ip_ttl, tcp->th_ack);
    }
}

/*
The parameter list is ugly. We could have just sent the complete ip header.
However, 
1. we need to swap the src and dest ip/port
2. the sequence no. is different in either direction.
3. ACK could be random? or same as header?
4. ident could be random? or same as header?
5. TTL could be random? or same as header?
*/

 /* the most important place, some key value should be taken into account */
static void createRSTpacket(struct  in_addr srcip, struct  in_addr destip, u_short sport, u_short dport, u_short ident, unsigned int seq, u_char  ttl, unsigned int ack) {
#if 1
    int sockfd;
    struct sockaddr_in dstaddr;
    char datagram[4096];  /* buffer for datagrams */
    struct sniff_ip *iph = (struct sniff_ip *) datagram;
    struct sniff_tcp *tcph = (struct sniff_tcp *) (datagram + sizeof (struct sniff_ip));
    int one = 1;
    const int *val = &one;
    struct pseudo_hdr *phdr;
    char temp_addr[INET_ADDRSTRLEN];

    if ((sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) < 0) {
        perror("createRSTpacket() sock failed:");
        exit(EXIT_FAILURE);
    }
    /* Recommended by Stevens: you need the "one" variable for setsockopt
    call so here it is*/
    if (setsockopt (sockfd, IPPROTO_IP, IP_HDRINCL, val, sizeof (one)) < 0){
        printf ("Warning: Cannot set HDRINCL from port %d to port %d\n", 
                ntohs(sport), ntohs(dport));
        perror("setsockopt: ");
    }

    strncpy(temp_addr, inet_ntoa(destip), INET_ADDRSTRLEN); /*BUG: destip or srcip?*/
    dstaddr.sin_family = AF_INET;
    dstaddr.sin_port = dport;
    inet_pton(AF_INET, temp_addr, &dstaddr.sin_addr);

    memset (datagram, 0, 4096);       /* zero out the buffer */
    iph->ip_vhl = 0x45;               /* version=4,header_length=5 */
    iph->ip_tos = 0;                  /* type of service not needed */
    /* 
    wierd thing [TODO][BUG]:
    htons() for linux
    no htons for mac os x/BSD 
    */
    iph->ip_len = htons(IPTCPHDRSIZE);     /* no payload for RST */
    iph->ip_id  = ident;              /* ID could this be random?*/
    iph->ip_off = 0;                  /* no fragmentation */
    iph->ip_ttl = ttl;                /* Time to Live, default:255 */
    iph->ip_src = srcip;              /* faking source device IP */
    iph->ip_dst = destip;             /* target destination address */
    iph->ip_sum = 0;                  /* Checksum is set to zero until computed */
    iph->ip_p   = IPPROTO_TCP;        /* IPPROTO_TCP or IPPROTO_UDP */
    iph->ip_sum = in_cksum((unsigned short *)iph, IPHDRSIZE); 

    /* From RFC793
    In all states except SYN-SENT, all reset (RST) segments are validated
    by checking their SEQ-fields.  A reset is valid if its sequence number
    is in the window.  In the SYN-SENT state (a RST received in response
    to an initial SYN), the RST is acceptable if the ACK field
    acknowledges the SYN.

    The receiver of a RST first validates it, then changes state.  If the
    receiver was in the LISTEN state, it ignores it.  If the receiver was
    in SYN-RECEIVED state and had previously been in the LISTEN state,
    then the receiver returns to the LISTEN state, otherwise the receiver
    aborts the connection and goes to the CLOSED state.  If the receiver
    was in any other state, it aborts the connection and advises the user
    and goes to the CLOSED state.
    */

    tcph->th_sport = sport;              /* faking source port */
    tcph->th_dport = dport;              /* target destination port */
    tcph->th_seq   = seq;                /* SYN sequence the should be 
                                            incremented in one dir and
                                            echoed in the other */
    tcph->th_ack   = 0;                     /* No ACK needed? or echo ACK?*/
    tcph->th_offx2 = 0x50;                  /* 50h (5 offset) ( 8 0s reserved )*/
    tcph->th_flags = TH_RST;                /* initial connection request FLAG*/

    /* attention */
    tcph->th_win   =  0;                 /* Window size default: htons(4500) + rand()%1000  */
    /* maximum allowed window size 65k*/
    tcph->th_urp   = 0;                  /* no urgent pointer */
    tcph->th_sum=0;                      /* Checksum is set to zero until computed */

    /* pseudo header for tcp checksum */
    phdr = (struct pseudo_hdr *) (datagram + IPTCPHDRSIZE);
    phdr->src = srcip.s_addr;
    phdr->dst = destip.s_addr;
    phdr->zero = 0;
    phdr->protocol = IPPROTO_TCP;
    phdr->tcplen = htons(TCPHDRSIZE);
    /* in bytes the tcp segment length default:0x14*/
    tcph->th_sum = in_cksum((unsigned short *)(tcph), IPTCPHDRSIZE);

    /*printf("RST packet IP Header\n");*/
    showPacketDetails(iph, tcph);

    if (sendto(sockfd, datagram, IPTCPHDRSIZE, 0, (struct sockaddr *)&dstaddr, sizeof(dstaddr)) < 0) {
        fprintf(stderr, "Error sending datagram: from port %d to port %d\n", 
              ntohs(sport), ntohs(dport));
        perror("sendto: ");
    }
    else {
        ankki_printf("verify: %s %d\n", inet_ntoa(dstaddr.sin_addr), ntohs(dstaddr.sin_port));
    }

    close(sockfd);
#endif
}


static void showPacketDetails(const struct sniff_ip *iph, const struct sniff_tcp *tcph)
{
    /*should cleanup: 0 to _DEBUG*/
#if _DEBUG
    printf(" vhl=%x\n",iph->ip_vhl);       
    printf(" tos=%x\n",iph->ip_tos);       
    printf(" len=%d IP+TCP hdr len=%lu\n",ntohs(iph->ip_len), IPTCPHDRSIZE);
    printf(" ide=%d\n",ntohs(iph->ip_id));
    printf(" off=%d\n",ntohs(iph->ip_off));
    printf(" ttl=%x\n",iph->ip_ttl);
    printf(" pro=%x\n",iph->ip_p);
    printf(" src=%s\n",inet_ntoa(iph->ip_src));
    printf(" dst=%s\n",inet_ntoa(iph->ip_dst));
    printf(" sum=%x\n",(iph->ip_sum)); /* no ntohs */

    printf(" sport=%d\n", ntohs(tcph->th_sport));
    printf(" dport=%d\n", ntohs(tcph->th_dport));
    printf(" seq=%x\n"  , ntohl(tcph->th_seq));  
    printf(" ack=%x\n"  , ntohl(tcph->th_ack));  
    printf(" offx2=%d\n", tcph->th_offx2);
    printf(" win=%d\n"  , ntohs(tcph->th_win));
    printf(" sum=%x\n"  , (tcph->th_sum)); /* no ntohs */
    printf(" urp=%d\n"  , tcph->th_urp);
    /*Print which flag is set in TCP*/
    readTCPflag(tcph->th_flags);
    printf("\n");
#endif
}

static void readTCPflag(u_char tcp_flags)
{
    /*printf("   th_flags (%x, %x)\t", tcp_flags, tcp_flags & TH_FLAGS);
    printf("   Flag: "); */
    if (tcp_flags & TH_FIN) { printf(" FIN"); }
    if (tcp_flags & TH_SYN) { printf(" SYN"); }
    if (tcp_flags & TH_RST) { printf(" RST"); }
    if (tcp_flags & TH_PUSH){ printf(" PUSH"); }
    if (tcp_flags & TH_ACK) { printf(" ACK"); }
    if (tcp_flags & TH_URG) { printf(" URG"); }
    if (tcp_flags & TH_ECE) { printf(" ECE"); }
    if (tcp_flags & TH_CWR) { printf(" CWR"); }
}

int main(int argc, char **argv)
{
    char dev[EXPSIZE];          /* capture device name */
    char errbuf[PCAP_ERRBUF_SIZE];  /* error buffer */
    /*
    * Expression			Description
    * ----------			-----------
    * ip					Capture all IP packets.
    * tcp					Capture only TCP packets.
    * tcp port 80			Capture only TCP packets with a port equal to 80.
    * ip host 10.1.2.3		Capture all IP packets to or from host 10.1.2.3.
    *
    ****************************************************************************
    *   tcp[13] == 0x10) or (tcp[13] == 0x18) for ACK and ACK+PUSH
    *  (tcp[13] == 0x10) for only ACK packets
    *  ip for any IP packet
    */
    char filter_exp[EXPSIZE] = "((vlan and (tcp[13] == 0x18)) or (tcp[13] == 0x18))";
    struct in_addr addr1, addr2;
	struct sigaction sa;
#if NOT_CMD
    pcap_if_t *alldevices, *device;
    pcap_addr_t listaddr;
    int i =0;
    int choice;
#else
    short tup_num = 1; /* 5 tuple counter */
    /* unsigned short port; */
    char para_buf[BUFSIZE];
    int opt;

	char dst_ip[IP_STR_SIZE];
	char src_ip[IP_STR_SIZE];
	unsigned dst_port = 0;
	unsigned src_port = 0;
	unsigned running_time = 0; /* snapper running time */
	unsigned timer_switch = 0; /* self exit timer switch */
	int write_file_flag = 0;
	int ar_flag = -1;

	memset(dev, '\0', EXPSIZE);
	memset(errbuf, '\0', PCAP_ERRBUF_SIZE);
	memset(dst_ip, '\0', IP_STR_SIZE);
	memset(src_ip, '\0', IP_STR_SIZE);
	memset(g_pid_file, '\0', BUFSIZE);
#endif

    /* Ctrl+C */
    signal (SIGINT, signal_handler);

	/* SIGTERM (i.e. kill -15 usually generated when reboot or shutdown) */
	sa.sa_handler = signal_handler;
	sigemptyset(&sa.sa_mask);
	if (sigaction(SIGTERM, &sa, NULL) < 0)
	{
		fprintf(stderr, "sigaction:%s\n", strerror(errno));
		exit(-1);
	}

    /* check for capture device name on command-line */
#if NOT_CMD
    print_app_banner();

    if (argc >= 2) {
		strncpy(dev, argv[1], sizeof(dev));
    }

    if (argc == 3) {
        strncpy(filter_exp, argv[2], strlen(argv[2]));
    }

    if (argc > 3 ) {
        fprintf(stderr, "error: unrecognized command-line options\n\n");
        print_app_usage();
        exit(EXIT_FAILURE);
    }
    else if (argc == 1 ) {
        if (pcap_findalldevs(&alldevices, errbuf) == -1) {
            fprintf(stderr,"Error in pcap_findalldevs: %s\n", errbuf);
            exit(1);
        }

        /* Print the list */
        for(device = alldevices; device; device = device->next) {
            printf("%d. %s", ++i, device->name);
            if (device->description)
            	printf(" (%s)\t", device->description);
            else
            	printf(" (No description available)\t");

            /* if (strcmp(device->name, "any") != 0 ) */
            {

                /* segment fault in ubuntu here, temprarily not solve */
                listaddr = device->addresses[0];


                switch(listaddr.addr->sa_family) {
                    case AF_INET:
                    inet_ntop(AF_INET, &(((struct sockaddr_in *)listaddr.addr)->sin_addr),
                              cnet, INET_ADDRSTRLEN);
                    break;

                    case AF_INET6:
                    inet_ntop(AF_INET6, &(((struct sockaddr_in6 *)listaddr.addr)->sin6_addr),
                              cnet, INET6_ADDRSTRLEN);
                    break;

                    default:
                    /*TODO: this is very strange...*/
                    inet_ntop(listaddr.addr->sa_family, &(((struct sockaddr_in *)listaddr.addr)->sin_addr),
                              cnet, INET_ADDRSTRLEN);
                    if(strlen(cnet)==0)
                    strcpy(cnet, "unknown");
                }
                printf("IP ADDR: %s\n", cnet);
            }
			/*
            else
            break;
			*/
        }
        if(i == 0) {
            printf("\nNo interfaces found! Make sure libpcap is installed.\n");
            return -1;
        }

        printf("Enter the interface number (1-%d):",i);
        scanf("%d", &choice);

        if(choice < 1 || choice > i) {
            printf("\nInterface number out of range.\n");
            /* Free the device list */
            pcap_freealldevs(alldevices);
            return -1;
        }

        /* Iterate the link list to the chosen device */
        for(device = alldevices, i = 0; i < choice-1 ; device = device->next, i++);

        /* the last one device?? */
		strncpy(dev, device->name, sizeof(dev));

        /*
        strcpy(cnet, inet_ntoa(((struct sockaddr_in*)device->addresses[0].addr)->sin_addr));
        printf("IP ADDR: %s\t",cnet);
        */

        if (dev == NULL) {
            fprintf(stderr, "Couldn't find default device: %s\n", errbuf);
            exit(EXIT_FAILURE);
        }
    }
#else
  if(-1 == checkDBTypeAuthorize("plzd"))
  {
       ankki_printf("check lience error!\n");
       return -1;
  }
  while (1)
  {
      static struct option long_options[] =
      {
          {"dst"      , required_argument, 0, 'd'},
          {"dstport"  , required_argument, 0, 'D'},
          {"interface", required_argument, 0, 'i'},
          {"src"      , required_argument, 0, 's'},
          {"srcport"  , required_argument, 0, 'S'},
          {"time"     , required_argument, 0, 't'},
          {"help"     ,       no_argument, 0, 'h'},
          {0, 0, 0, 0}
      };

      int option_index = 0;

      memset(para_buf, '\0', BUFSIZE);

      opt = getopt_long(argc, argv, "d:D:i:s:S:t:", long_options, &option_index);

      if (opt == -1)
            break;

      switch (opt)
      {
          case 'i':
          memset(dev, '\0', sizeof(dev));
          strncpy(dev, optarg, sizeof(dev)); 
          break;

          /* destination ip address */
          /* expression as src or dst x.x.x.x */
          /* no ip format check, validated by pcap compiler */
          case 'd':
          snprintf(para_buf, BUFSIZE, " and (src or dst %s)", optarg);
		  strncpy(dst_ip, optarg, IP_STR_SIZE);
		  write_file_flag += !!strlen(dst_ip);
          tup_num++;
          break;
          
          /* destination port */
          /* expression as port 21 */
          case 'D':
          snprintf(para_buf, BUFSIZE, " and port %s", optarg);
		  dst_port = atoi(optarg);
		  write_file_flag += !!dst_port;
          tup_num++;
          break;

          /* source ip address */
          /* expression as src or dst x.x.x.x */
          case 's':
          snprintf(para_buf, BUFSIZE, " and (src or dst %s)", optarg);
		  strncpy(src_ip, optarg, IP_STR_SIZE);
		  write_file_flag += !!strlen(src_ip);
          tup_num++;
          break;

          /* source port */
          /* expression as port 21 */
          case 'S':
          snprintf(para_buf, BUFSIZE, " and port %s", optarg);
		  src_port = atoi(optarg);
		  write_file_flag += !!src_port;
          tup_num++;
          break;

		  /* total running time and then exit by itself */
          case 't':
          running_time = atoi(optarg);
		  if (0 == running_time)
		  {
		      ankki_printf("time parameter error, use default\n");
			  running_time = DEFAULT_RUNNING_TIME;
		  }
		  timer_switch = 1; /* enable timer switch */
          tup_num++;
          break;

		  case 'h':
		  print_app_usage();
		  abort();
          break;

          case '?':
          break;

          default:
          print_app_usage();
          abort();
          break;
      }
    strncat(filter_exp, para_buf, EXPSIZE);
  }

  if (strlen(dev) == 0) {
      fprintf(stderr, "Couldn't find default device: %s\n", dev);
      print_app_usage();
      exit(EXIT_FAILURE);
  }

  if (optind != argc || (optind & 0x1) != 1)
  {
      fprintf(stderr, "parameter invalid\n");
      print_app_usage();
      exit(EXIT_FAILURE);
  }

  if (tup_num != 5)
  {
      ankki_printf("WARNING: 5 tuple info needed to locate a stream, if you still go, it will reset a stream unexpected\n");
  }

  /* record pid and keep the same process only once */
  ankki_printf("\n\nwrite_file_flag = %d\n", write_file_flag);
  if (write_file_flag != 0)
  {
	  snprintf(g_pid_file, BUFSIZE, "%s/%s-%u_%s-%u", SNAPPER_PID_DIR, dst_ip, dst_port, src_ip, src_port);
	  ar_flag = already_running(g_pid_file);

	  switch (ar_flag)
	  {
	      case 0:
		      {
			      ankki_printf("running first time!\n");
			  }break;
		  case 1:
			  {
				  ankki_printf("the same process already running!\n");
				  exit(0);
			  }break;
		  case -1:
			  {
				  ankki_printf("some error happens!\n");
				  exit(-1);
			  }break;
		  default:
			  {
				  ankki_printf("Unknown return value: #%d\n", ar_flag);
			  }break;
	  }
  }

  if (0 == strlen(dev)) {
      fprintf(stderr, "Couldn't find default device: %s\n", errbuf);
      exit(EXIT_FAILURE);
  }
#endif

  /* get network number and mask associated with capture device */
  if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) {
#if _DEBUG
      fprintf(stderr, "Couldn't get netmask for device %s: %s\n",
              dev, errbuf);
#endif
      net = 0;
      mask = 0;
  }
  else {
      addr1.s_addr = net;
      strcpy(cnet, inet_ntoa(addr1));
      addr2.s_addr = mask;
      strcpy(cmask, inet_ntoa(addr2));
      ankki_printf("NET: %s %x CMASK: %s %x\n",cnet, htonl(net), cmask, htonl(mask));
  }

  /* print capture info */
  ankki_printf("Device: %s\n", dev);
  /*printf("Number of packets: %d\n", CAPTURE_COUNT);*/
  ankki_printf("Filter expression: %s\n", filter_exp);

  /* open capture device */
  handle = pcap_open_live(dev, SNAP_LEN, 1, 0, errbuf);
  if (handle == NULL) {
      fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
      exit(EXIT_FAILURE);
  }

  /* make sure we're capturing on an Ethernet device [2] */
  if (pcap_datalink(handle) != DLT_EN10MB) {
      fprintf(stderr, "%s is not an Ethernet\n", dev);
      exit(EXIT_FAILURE);
  }

  /* compile the filter expression */
  if (pcap_compile(handle, &fp, filter_exp, 0, net) == -1) {
      fprintf(stderr, "Couldn't parse filter %s: %s\n",
              filter_exp, pcap_geterr(handle));
      exit(EXIT_FAILURE);
  }

  /* apply the compiled filter */
  if (pcap_setfilter(handle, &fp) == -1) {
      fprintf(stderr, "Couldn't install filter %s: %s\n",
              filter_exp, pcap_geterr(handle));
      exit(EXIT_FAILURE);
  }

  /* set alarm timer */
  if (1 == timer_switch)
  {
      signal(SIGALRM, signal_handler_alarm);
	  alarm(running_time);
  }
  
  /* now we can set our callback function */
#if 1
  pcap_loop(handle, CAPTURE_COUNT, got_packet, NULL);
#else
  /* 
   * this function can result a timeout machanism but will 
   * cause rst packet ineffective because of sending delay 
   */
  pcap_dispatch(handle, CAPTURE_COUNT, got_packet, NULL);
#endif
  
  return 0;
}
