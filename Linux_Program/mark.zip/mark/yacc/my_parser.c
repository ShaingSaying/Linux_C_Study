#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "my_parser.h"

dlist_t *sql_string_list;
//dlist_t *expression_list;

sql_info_t *sql_info;
parse_node_t *sql_info_out;


#if 0
int main()
{
    sql_info_out = (node *)malloc(sizeof(node));
    memset(sql_info_out, 0x00, sizeof(node));

    char buf[1024] = {0};
    #if 0
	snprintf(buf, sizeof(buf), "SELECT a, b FROM users where c = 1");
    //snprintf(buf, sizeof(buf), "delete from user_t where a = 1");
    #else
    int i = 0;
    scanf("%c", &buf[i]);
    while (buf[i] != ';' && i < 1024) 
    {
        scanf("%c", &buf[++i]);
    }
    #endif

    sql_parse(buf, sql_info_out);

    printf("---\n");
    printf("%s\n", sql_info_out->oper);
    printf("%s\n", sql_info_out->table);
    printf("%d\n", sql_info_out->table_num);
    printf("%s\n", sql_info_out->rows);

    free(sql_info_out);
    return 0;
}

#endif


void replace_dq_char(char *ch, char c_dst, char c_src )
{
	if (ch == NULL)
	{
		return;
	}
	int len = strlen(ch) + 1;
	int i = 0;
	int j;

	for (i; i < len; i++)
	{
		if(ch[i] == c_dst || ch[i]==0x0a || ch[i]==0x0b || ch[i]==0x0c || ch[i]==0x0d)
		{
			if (ch[i + 1] != c_dst &&  ch[i + 1]!=0x0a && ch[i + 1]!=0x0b && ch[i + 1]!=0x0c && ch[i + 1]!=0x0d)
			{
				if(ch[i+1] == '.' || ch[i-1] == '.')
				{
					for(j = i;j < len;j++)
					{
						ch[j] = ch[j+1];
					}
				}
				else
				{
					ch[i] = c_src;
				}
				
			}
		}
	}
	return;
}







int sql_parse(char *sql_buff, parse_node_t *sql_info_out)
{
    int ret = -1;
    char *p = NULL;
    int i = 0;
    
    if(NULL == sql_buff || NULL == sql_info_out)
    {
        LOG_DEBUG("sql_parse param error");
        return -1;
    }
	/*ȥ��˫����*/
    replace_dq_char(sql_buff, '\"', 0x20);
	
    sql_string_list = dlist_create();
    RETURN_IF_NULL_PTR(sql_string_list);

    sql_info = (sql_info_t *)malloc(sizeof(sql_info_t));
    RETURN_IF_NULL_PTR(sql_info);
    memset(sql_info, 0x00, sizeof(sql_info_t));
    
    sql_info->tables = dlist_create();
    RETURN_IF_NULL_PTR(sql_info->tables);
    
    sql_info->rows = dlist_create();
    RETURN_IF_NULL_PTR(sql_info->rows);

	//yacc工作
    scan_buffer(sql_buff);
    
    if(0 == strlen(sql_info->operate_type))
    {
        p = sql_buff;
		while(p != NULL && *p == ' ')
		{
			p++;
		}
        while(p != NULL && *p != ' ' && i < 20)
        {
            sql_info_out->oper[i++] = *p++;
        }
    }
    else
    {
        memcpy(sql_info_out->oper, sql_info->operate_type, 30);
    }
	
	if(0 != strlen(sql_info->db_name))
	{
		memcpy(sql_info_out->db_name,sql_info->db_name,30);
	}
    
    copy_sql_tables(sql_info_out);
    copy_sql_rows(sql_info_out);
    sql_info_out->table_num = sql_info->tables->len;

    destroy_sql_string_list();
    destroy_sql_tables_list();
    destroy_sql_rows_list();
    CHECK_FREE(sql_info);
	return 0;
}


int set_db_name(char* str)
{
	if(NULL == str) 
        return -1;

    memcpy(sql_info->db_name, str, strlen(str) < sizeof(sql_info->db_name) ? strlen(str) : sizeof(sql_info->db_name) - 1);
    return 0;
}



int set_operate_type(char *str)
{
    if(NULL == str) 
        return -1;

    memcpy(sql_info->operate_type, str, strlen(str) < sizeof(sql_info->operate_type) ? strlen(str) : sizeof(sql_info->operate_type) - 1);
    return 0;
}

int set_table_name(char *str)
{
    if(NULL == str || NULL == sql_info->tables) 
        return -1;


    size_t size = strlen(str) + 1;
    char *tmp = (char *)malloc(size);
    memset(tmp, 0x00, size);
    memcpy(tmp, str, strlen(str));

    if(0 != dlist_find_str_uncase(sql_info->tables, tmp))
    {
        dlist_insert_tail(sql_info->tables, tmp);
    }
    else
    {
        free(tmp);
    }

    //dlist_find_insert_from_tail(sql_info->rows, tmp);
    return 0;
}

int set_sql_rows_combine(const char *str1, const char *str2)
{
    if(NULL == str1 || NULL == str2 || NULL == sql_info->rows)
    {
        LOG_DEBUG("set_sql_rows_combine param error");
        return -1;
    }

    //LOG_DEBUG("set_sql_rows_combine");
    
    size_t size = strlen(str1) + strlen(str2) + 1;
    char *tmp = (char *)malloc(size);
    memset(tmp, 0x00, size);
    snprintf(tmp, size, "%s%s", str1, str2);

    if(0 != dlist_find_str_uncase(sql_info->rows, tmp))
    {
        dlist_insert_tail(sql_info->rows, tmp);
    }
    else
    {
        free(tmp);
    }

    //dlist_find_insert_from_tail(sql_info->rows, tmp);
    return 0;
}

int set_sql_rows(const char *str)
{
    if(NULL == str || NULL == sql_info->rows)
    {
        LOG_DEBUG("set_sql_rows param error");
        return -1;
    }
    
    size_t size = strlen(str) + 1;
    char *tmp = (char *)malloc(size);
    memset(tmp, 0x00, size);
    memcpy(tmp, str, strlen(str));

    if(0 != dlist_find_str_uncase(sql_info->rows, tmp))
    {
        dlist_insert_tail(sql_info->rows, tmp);
    }
    else
    {
        free(tmp);
    }

    //dlist_find_insert_from_tail(sql_info->rows, tmp);
    return 0;
}

int copy_sql_tables(parse_node_t *sql_info_out)
{
    if(NULL == sql_info_out)
    {
        return -1;
    }
	if(NULL == sql_info->rows)
	{
        return -1;
	}	
	dlist_t *tables = sql_info->tables;
	dlist_entry_t *item = NULL;
	list_for_each(item, tables->head, tables->tail)
	{
        if(0 == strlen(sql_info_out->table))
        {
            snprintf(sql_info_out->table, sizeof(sql_info_out->table), "%s", (char *)item->data);
        }
        else
        {
            snprintf(sql_info_out->table + strlen(sql_info_out->table), sizeof(sql_info_out->table) - strlen(sql_info_out->table), ",%s", (char *)item->data);
        }
	}
	
	return 0;
}

int copy_sql_rows(parse_node_t *sql_info_out)
{
	if(NULL == sql_info->rows)
		return -1;
	
	dlist_t *rows = sql_info->rows;
	dlist_entry_t *item = NULL;
	list_for_each(item, rows->head, rows->tail)
	{
        if(0 == strlen(sql_info_out->rows))
        {
            snprintf(sql_info_out->rows, sizeof(sql_info_out->rows), "%s", (char *)item->data);
        }
        else
        {
            snprintf(sql_info_out->rows + strlen(sql_info_out->rows), sizeof(sql_info_out->rows) - strlen(sql_info_out->rows), ",%s", (char *)item->data);
        }
	}
	
	return 0;
}

int destroy_sql_tables_list()
{
    dlist_destroy(sql_info->tables); 
    return 0;
}

int destroy_sql_rows_list()
{
    dlist_destroy(sql_info->rows); 
    return 0;
}

char* get_sql_string(const char *sql_string)
{
    if(NULL == sql_string)
    {
        return NULL;
    }

    //LOG_DEBUG("sql_string:%s", sql_string);
    
    size_t size = strlen(sql_string) + 1;
    char *tmp = (char *)malloc(size);
    memset(tmp, 0x00, size);
    memcpy(tmp, sql_string, strlen(sql_string));
    dlist_insert(sql_string_list, tmp);
    //printf("l:%s, %p\n", sql_string, sql_string);
    //free(sql_string);
    return tmp;
}

int destroy_sql_string_list()
{
    dlist_destroy(sql_string_list);
    return 0;
}

