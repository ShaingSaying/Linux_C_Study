#ifndef __MY_PARSER_H__
#define __MY_PARSER_H__
#include "dlist.h"
#include "logger.h"
#include "sql_parse.h"
#ifdef __cplusplus
extern "C" {
#endif

/*
typedef struct sql_info_out_s sql_info_out_t;
struct sql_info_out_s
{
    char operate_type[30];
    char table_name[200];
    char rows[1024];
    int table_num;
};
*/

typedef struct sql_info_s sql_info_t;
struct sql_info_s
{
	char db_name[30];
    char operate_type[30];
    dlist_t *tables;
    dlist_t *rows;
};

void replace_dq_char(char *ch, char c_dst, char c_src );
int scan_buffer(const char * data); 
//int sql_parse(char *sql_buff, parse_node_t *sql_info_out);
int set_db_name(char* str);
int set_operate_type(char *str);
int set_table_name(char *str);
int set_sql_rows_combine(const char *str1, const char *str2);
int set_sql_rows(const char *str);
int copy_sql_tables(parse_node_t *sql_info_out);
int copy_sql_rows(parse_node_t *sql_info_out);
int destroy_sql_rows_list();

char* get_sql_string(const char *sql_string);
int destroy_sql_tables_list();
int destroy_sql_string_list();

#ifdef __cplusplus
}
#endif

#endif

